package testcase;

import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.OrganisationPage;
import automation.pages.utils.ExtentListener;

public class InvalidOrganisationTestCase extends BaseTest {

    @Test(description =
            "Verifies the organisation settings by selecting the configured "
            + "language, time zone and authentication options.")
    public void verifyOrganisationMandatoryValidation() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Organisation settings");
        ExtentListener.getTest().info("• Select configured language");
        ExtentListener.getTest().info("• Select configured time zone");
        ExtentListener.getTest().info("• Open Advanced Options");
        ExtentListener.getTest().info("• Enable configured authentication options");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The Organisation settings page should open successfully and "
                + "the configured language, time zone and authentication options "
                + "should be selectable."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Organisation settings"
        );

        OrganisationPage organisationPage =
                new OrganisationPage(driver);

        organisationPage.clickAdminMenu();
        organisationPage.clickOrganisation();

        ExtentListener.getTest().info(
                "Step 3: Select the configured Organisation language"
        );

        organisationPage.SelectLanguage(config.getlanguage());

        ExtentListener.getTest().info(
                "Step 4: Select the configured Organisation time zone"
        );

        organisationPage.selectTimeZone(config.gettimeZone());

        ExtentListener.getTest().info(
                "Step 5: Open Advanced Options"
        );

        organisationPage.clickAdvancedOption();

        ExtentListener.getTest().info(
                "Step 6: Enable the configured authentication options"
        );

        String[] checkBoxIds = {
                config.getAuth1(),
                config.getAuth2(),
                config.getAuth3(),
                config.getAuth4()
        };

        for (String id : checkBoxIds) {
            organisationPage.enableCheckBox(id);
        }

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Organisation settings page was opened successfully. "
                + "The configured language and time zone were selected, and "
                + "the configured authentication options were enabled."
        );
    }
}