package testcase;

import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.ToolsPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class Tools_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to Users Tags, "
            + "open Add New, enter a User Tag name and perform the Add operation.")
    public void verifyAddTools() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Users Tools");
        ExtentListener.getTest().info("• Navigate to Tags");
        ExtentListener.getTest().info("• Click Add New");
        ExtentListener.getTest().info("• Enter User Tag name");
        ExtentListener.getTest().info("• Click Add");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to navigate to Users Tags, "
                + "enter a valid User Tag name and perform the Add operation."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                config.getEmail(),
                config.getPassword()
        );

        ExtentListener.getTest().info(
                "Step 2: Navigate to Users Tools"
        );

        ToolsPage toolsPage = new ToolsPage(driver);

        toolsPage.Clickadmin();
        toolsPage.ClickTools();
        toolsPage.ClickUsers();

        ExtentListener.getTest().info(
                "Step 3: Navigate to Tags"
        );

        toolsPage.ClickTags();

        ExtentListener.getTest().info(
                "Step 4: Click Add New"
        );

        toolsPage.Clickaddnew();

        ExtentListener.getTest().info(
                "Step 5: Enter User Tag name"
        );

        toolsPage.enterTagName("Automation Tags");

        ExtentListener.getTest().info(
                "<b>User Tag Name:</b> Automation Tags"
        );

        ExtentListener.getTest().info(
                "Step 6: Click Add"
        );

        toolsPage.clickAdd();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to Users Tags, "
                + "entered the User Tag name <b>Automation Tags</b> and performed "
                + "the Add operation."
        );
    }
}