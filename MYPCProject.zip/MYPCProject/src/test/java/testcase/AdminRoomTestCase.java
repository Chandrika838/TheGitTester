package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.AdminRoomPage;
import automation.pages.utils.ConfigReader;

public class AdminRoomTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(
        description = "Verifies that an administrator can create a new room with valid room details, location, preparation settings, and room tags."
    )
    public void verifyAddRoom() {

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
            config.getEmail(),
            config.getPassword()
        );


        AdminRoomPage room = new AdminRoomPage(driver);

        room.ClickAdmin();
        
        Assert.assertTrue(
                room.isAdminDispalyed(),
                "Admin is not displayed"
            );


        room.ClickRoom();

        Assert.assertTrue(
            room.isRoomDisplayed(),
            "Room is not displayed"
        );

        room.ClickAddNew();
        
        Assert.assertTrue(
                room.isAddNewDisplayed(),
                "Add New button is not displayed"
            );


      
        room.enterRoomName(
            config.getRoomName()
        );
        

        Assert.assertTrue(
            room.isRoomNameDisplayed(),
            "Room Name field is not displayed"
        );


    
        Assert.assertTrue(
            room.isLocationDisplayed(),
            "Location dropdown is not displayed"
        );


        room.selectLocation(
            config.getLocation()
        );

        
        room.enterDefaultDUration(config.getDuration());
        
        room.enterCapacityvalue(config.getCapacity());
        
        room.ClickAdvanceOption1();


        room.enablecheckRoomCamera();

        room.enablecheckRoomMonitor();


        room.enablecheckRoomProjector();


        Assert.assertTrue(
            room.isPrepartionDisplayed(),
            "Preparation dropdown is not displayed"
        );


        room.selectPrepartion(
            config.getPrepration()
        );


        room.selectCheckBox();



        room.clickTagsandBooking();

        room.clickTagsAdd();


        room.selectTags(
            config.getRoomTags()
        );


        

        Assert.assertTrue(
            room.isSubmitDisplayed(),
            "Submit button is not displayed"
        );


        room.clickSubmit();
    }
}