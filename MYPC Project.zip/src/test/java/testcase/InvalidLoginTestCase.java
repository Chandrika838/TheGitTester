package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import automation.pages.utils.ExtentListener;

public class InvalidLoginTestCase extends BaseTest {

    @Test(description =
            "Verifies that the system displays an error message when invalid "
            + "email and password credentials are entered.")
    public void verifyInvalidLogin() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Enter invalid email address");
        ExtentListener.getTest().info("• Enter invalid password");
        ExtentListener.getTest().info("• Click Login");
        ExtentListener.getTest().info("• Verify invalid credentials message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should reject the invalid credentials and display "
                + "an appropriate invalid login message."
        );

        LoginPage loginPage = new LoginPage(driver);

        ExtentListener.getTest().info(
                "Step 1: Enter invalid email address"
        );

        loginPage.enterEmail("Invalid emailid");

        ExtentListener.getTest().info(
                "Step 2: Enter invalid password"
        );

        loginPage.enterPassword("Wrong123");

        ExtentListener.getTest().info(
                "Step 3: Click Login"
        );

        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 4: Verify invalid credentials message"
        );

        Assert.assertTrue(
                loginPage.isInvalidMessageDisplayed(),
                "Invalid credentials message is not displayed"
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Login was rejected and the invalid credentials message "
                + "was displayed as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays an error message when an invalid "
            + "email address is entered with a valid password.")
    public void verifyLoginwithInvalidEmail() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Enter invalid email address");
        ExtentListener.getTest().info("• Enter valid password");
        ExtentListener.getTest().info("• Click Login");
        ExtentListener.getTest().info("• Verify invalid login message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should reject the login attempt and display "
                + "an appropriate invalid login message."
        );

        LoginPage loginPage = new LoginPage(driver);

        ExtentListener.getTest().info(
                "Step 1: Enter invalid email address"
        );

        loginPage.enterEmail("test@123");

        ExtentListener.getTest().info(
                "Step 2: Enter valid password"
        );

        loginPage.enterPassword(config.getPassword());

        ExtentListener.getTest().info(
                "Step 3: Click Login"
        );

        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 4: Verify invalid login message"
        );

        Assert.assertTrue(
                loginPage.isInvalidMessageDisplayed(),
                "Invalid Login message is not Displayed"
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Login was rejected because an invalid email address was entered. "
                + "The invalid login message was displayed as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays an error message when an invalid "
            + "password is entered with a valid email address.")
    public void verifyLoginwithInvalidPassword() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Enter valid email address");
        ExtentListener.getTest().info("• Enter invalid password");
        ExtentListener.getTest().info("• Click Login");
        ExtentListener.getTest().info("• Verify invalid password message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should reject the login attempt and display "
                + "the invalid password message."
        );

        LoginPage loginPage = new LoginPage(driver);

        ExtentListener.getTest().info(
                "Step 1: Enter valid email address"
        );

        loginPage.enterEmail(config.getEmail());

        ExtentListener.getTest().info(
                "Step 2: Enter invalid password"
        );

        loginPage.enterPassword("test1233");

        ExtentListener.getTest().info(
                "Step 3: Click Login"
        );

        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 4: Verify invalid password message"
        );

        Assert.assertTrue(
                loginPage.isInvalidPasswordDisplayed(),
                "Invalid Password is not Displayed"
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Login was rejected because an invalid password was entered. "
                + "The invalid password message was displayed as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays an error message when the "
            + "email address is left blank during login.")
    public void verifyLoginBlankEmailID() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Leave email address blank");
        ExtentListener.getTest().info("• Enter valid password");
        ExtentListener.getTest().info("• Click Login");
        ExtentListener.getTest().info("• Verify required field error message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent login when the email address is blank "
                + "and display the appropriate error message."
        );

        LoginPage loginPage = new LoginPage(driver);

        ExtentListener.getTest().info(
                "Step 1: Leave email address blank"
        );

        loginPage.enterEmail(" ");

        ExtentListener.getTest().info(
                "Step 2: Enter valid password"
        );

        loginPage.enterPassword(config.getPassword());

        ExtentListener.getTest().info(
                "Step 3: Click Login"
        );

        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 4: Verify error message"
        );

        Assert.assertTrue(
                loginPage.isErrorMessageDisplayed(),
                "Error Message is not Displayed"
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Login was prevented because the email address was left blank. "
                + "The required field error message was displayed as expected."
        );
    }
}
	