package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.OrganisationPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class Organisation extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can configure Organisation settings "
            + "including Time Zone, Authentication, Tooltip and Resource options.")
    public void verifyOrganisationSettings() {

        // =========================
        // SCENARIOS COVERED
        // =========================

        ExtentListener.getTest().info(
                "<b>Scenarios Covered:</b>"
        );

        ExtentListener.getTest().info(
                "• Login with valid administrator credentials"
        );

        ExtentListener.getTest().info(
                "• Navigate to Organisation settings"
        );

        ExtentListener.getTest().info(
                "• Select configured Time Zone"
        );

        ExtentListener.getTest().info(
                "• Verify Time Zone is displayed"
        );

        ExtentListener.getTest().info(
                "• Open Advanced Options"
        );

        ExtentListener.getTest().info(
                "• Enable Rezzervi authentication"
        );

        ExtentListener.getTest().info(
                "• Enable Google authentication"
        );

        ExtentListener.getTest().info(
                "• Enable Microsoft authentication"
        );

        ExtentListener.getTest().info(
                "• Enable Entra ID authentication"
        );

        ExtentListener.getTest().info(
                "• Enable Library ID authentication"
        );

        ExtentListener.getTest().info(
                "• Enable Booking Tooltip"
        );

        ExtentListener.getTest().info(
                "• Enable Username"
        );

        ExtentListener.getTest().info(
                "• Enable Room resource"
        );

        ExtentListener.getTest().info(
                "• Enable Desk resource"
        );

        ExtentListener.getTest().info(
                "• Enable PC resource"
        );

        ExtentListener.getTest().info(
                "• Verify Submit button"
        );

        ExtentListener.getTest().info(
                "• Save Organisation settings"
        );


        // =========================
        // EXPECTED RESULT
        // =========================

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The Organisation settings should be configured successfully. "
                + "The selected Time Zone and required authentication, tooltip, "
                + "username and resource options should be enabled, and the "
                + "settings should be saved successfully."
        );


        // =========================
        // STEP 1 - LOGIN
        // =========================

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                config.getEmail(),
                config.getPassword()
        );


        // =========================
        // STEP 2 - NAVIGATION
        // =========================

        ExtentListener.getTest().info(
                "Step 2: Navigate to Organisation settings"
        );

        OrganisationPage organisationPage =
                new OrganisationPage(driver);

        organisationPage.clickAdminMenu();

        organisationPage.clickOrganisation();


        // =========================
        // STEP 3 - TIME ZONE
        // =========================

        ExtentListener.getTest().info(
                "Step 3: Select the configured Organisation Time Zone"
        );

        organisationPage.selectTimeZone(
                config.gettimeZone()
        );


        // =========================
        // STEP 4 - VERIFY TIME ZONE
        // =========================

        ExtentListener.getTest().info(
                "Step 4: Verify that Time Zone is displayed"
        );

        Assert.assertTrue(
                organisationPage.isTimeZoneDisplayed(),
                "Time Zone is not displayed"
        );


        // =========================
        // STEP 5 - ADVANCED OPTIONS
        // =========================

        ExtentListener.getTest().info(
                "Step 5: Open Advanced Options"
        );

        organisationPage.clickAdvancedOption();


        // =========================
        // STEP 6 - AUTHENTICATION
        // =========================

        ExtentListener.getTest().info(
                "Step 6: Enable Authentication options"
        );

        organisationPage.enableAllowUsers(config.getAuth1());

        organisationPage.enableGoogleUsers(config.getAuth2());
       
        organisationPage.enableMicrosoft(config.getAuth3());

        organisationPage.enableEntraID(config.getAuth4());

        organisationPage.enableLibrayID(config.getAuth5());


        // =========================
        // STEP 7 - TOOLTIP AND USERNAME
        // =========================

        ExtentListener.getTest().info(
                "Step 7: Enable Booking Tooltip and Username options"
        );

        organisationPage.enableCheckBox(
                "showBookingTooltipForOthers"
        );

        organisationPage.enableCheckBox(
                "showUsername"
        );


        // =========================
        // STEP 8 - RESOURCES
        // =========================

        ExtentListener.getTest().info(
                "Step 8: Enable Room, Desk and PC resource options"
        );

        organisationPage.enableCheckBox(
                "showRoom"
        );

        organisationPage.enableCheckBox(
                "showDesk"
        );

        organisationPage.enableCheckBox(
                "showPc"
        );


        // =========================
        // STEP 9 - VERIFY SUBMIT
        // =========================

        ExtentListener.getTest().info(
                "Step 9: Verify Submit button is displayed"
        );

        Assert.assertTrue(
                organisationPage.isDisplayedSubmit(),
                "Submit button is not displayed"
        );


        // =========================
        // STEP 10 - SUBMIT
        // =========================

        ExtentListener.getTest().info(
                "Step 10: Save Organisation settings"
        );

        organisationPage.clickSubmit();


        // =========================
        // ACTUAL RESULT
        // =========================

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Organisation settings were configured successfully. "
                + "The configured Time Zone was selected and verified. "
                + "The required Authentication, Tooltip, Username and "
                + "Resource options were enabled, and the Submit action "
                + "was performed successfully."
        );
    }
}