package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.Room_BookingPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class RoomBookingTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to Room Booking Rules, "
            + "add a new booking rule, select User Tag and Room Tag, and continue "
            + "to the next step.")
    public void verifyRoomBooking() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Room Booking Rules");
        ExtentListener.getTest().info("• Click Add New");
        ExtentListener.getTest().info("• Select User Tag");
        ExtentListener.getTest().info("• Select Room Tag");
        ExtentListener.getTest().info("• Click Continue");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to navigate to Room Booking Rules, "
                + "create a new booking rule, select the required User Tag and Room Tag, "
                + "and continue to the next step."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Room Booking Rules"
        );

        Room_BookingPage bookingPage =
                new Room_BookingPage(driver);

        bookingPage.clickAdmin();
        bookingPage.clickTools();
        bookingPage.clickRooms();
        bookingPage.clickBookingRules();

        ExtentListener.getTest().info(
                "Step 3: Click Add New"
        );

        bookingPage.clickAddNew();

        ExtentListener.getTest().info(
                "Step 4: Select User Tag"
        );

        bookingPage.selectUserTag(
                config.getUsersTag()
        );

        ExtentListener.getTest().info(
                "Step 5: Select Room Tag"
        );

        bookingPage.selectRoomTag(
                config.getRoomTags()
        );

        ExtentListener.getTest().info(
                "Step 6: Click Continue"
        );

        bookingPage.clickContinue();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to Room Booking Rules, "
                + "opened Add New, selected the configured User Tag and Room Tag, and clicked "
                + "Continue successfully."
        );
    }
}
