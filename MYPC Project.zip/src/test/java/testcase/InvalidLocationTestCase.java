package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LocationPage;
import adminpage.LoginPage;
import automation.pages.utils.ExtentListener;

public class InvalidLocationTestCase extends BaseTest {

    @Test(description =
            "Verifies that the system displays the validation message when "
            + "an administrator attempts to create a Location with a blank Location Name.")
    public void VerifyBlankLocation() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Location");
        ExtentListener.getTest().info("• Open Add New Location");
        ExtentListener.getTest().info("• Leave Location Name blank");
        ExtentListener.getTest().info("• Select Parent Location");
        ExtentListener.getTest().info("• Enable Time Zone");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent Location creation when the Location Name "
                + "is blank and display the appropriate validation message."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Location and open Add New"
        );

        LocationPage loc = new LocationPage(driver);

        loc.ClickAdmin();
        loc.ClickLocation();
        loc.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave the Location Name blank"
        );

        loc.enterLocationName("");

        ExtentListener.getTest().info(
                "Step 4: Configure Parent Location and Time Zone"
        );

        loc.ClickAdvanceOptions();
        loc.SelectParentLocation(config.getparentLocation());
        loc.enableTimeZone();

        ExtentListener.getTest().info(
                "Step 5: Click Add"
        );

        loc.ClickAdd();

        ExtentListener.getTest().info(
                "Step 6: Verify validation message is displayed"
        );

        Assert.assertTrue(
                loc.InvalidBlankDisplayed(),
                "Invalid Blank Message is not Displayed"
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Location creation was prevented because the Location Name "
                + "was left blank. The system displayed the expected validation message."
        );
    }
}