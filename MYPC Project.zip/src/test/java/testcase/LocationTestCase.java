package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LocationPage;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class LocationTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can successfully create a new location "
            + "with advanced options, working hours, and custom non-working day configuration.")
    public void verifyAddLocation() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Locations");
        ExtentListener.getTest().info("• Create a new Location");
        ExtentListener.getTest().info("• Configure Parent Location");
        ExtentListener.getTest().info("• Configure Time Zone");
        ExtentListener.getTest().info("• Configure Working Hours");
        ExtentListener.getTest().info("• Configure Custom Non-Working Days");
        ExtentListener.getTest().info("• Submit the Location");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to create a new location with all " +
                "configured settings successfully."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                config.getEmail(),
                config.getPassword()
        );

        ExtentListener.getTest().info(
                "Step 2: Navigate to Location Management"
        );

        LocationPage locationPage = new LocationPage(driver);

        Assert.assertTrue(
                locationPage.isAdminDisplayed(),
                "Admin is not Displayed"
        );

        locationPage.ClickAdmin();

        Assert.assertTrue(
                locationPage.isLocationDisplayed(),
                "Location is not displayed"
        );

        locationPage.ClickLocation();

        ExtentListener.getTest().info(
                "Step 3: Click Add New Location"
        );

        locationPage.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 4: Enter Location Name"
        );

        locationPage.enterLocationName(config.getLocation());

        ExtentListener.getTest().info(
                "Step 5: Open Advanced Options"
        );

}
    
}