Feature: Desk Report functionality

  Scenario: Verify Desk Report
    Given I open the application
    When I enter valid email
    And I enter valid password
    And I click the login button
    When I click Reports for Desk Report
    And I click Desk Report
    And I select the desk report location
    And I select the desk report month
    And I select the desk report booking type