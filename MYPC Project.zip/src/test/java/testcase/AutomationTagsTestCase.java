package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.AutomationTags;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class AutomationTagsTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can configure Automation Tags, "
            + "General Rules, User Rules, Room Rules, Desk Rules and Computer Rules.")
    public void verifyAutomationTags() {

    
        // SCENARIOS COVERED
      
        ExtentListener.getTest().info(
                "<b>Scenarios Covered:</b>"
        );

        ExtentListener.getTest().info(
                "• Login with valid administrator credentials"
        );

        ExtentListener.getTest().info(
                "• Navigate to Admin → Tools → User Tools → Admin Policy → Automation Tags"
        );

        ExtentListener.getTest().info(
                "• Configure User Reports, Room Reports, Desk Reports and Computer Reports"
        );

        ExtentListener.getTest().info(
                "• Configure User Rules"
        );

        ExtentListener.getTest().info(
                "• Configure Room Rules"
        );

        ExtentListener.getTest().info(
                "• Configure Desk Rules"
        );

        ExtentListener.getTest().info(
                "• Configure Computer Rules"
        );

        ExtentListener.getTest().info(
                "• Verify Update button and save the Automation Tags configuration"
        );

        // EXPECTED RESULT
 
        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to navigate to Automation Tags, " +
                "configure the required report and user/resource rules, " +
                "and update the configuration successfully."
        );
        
        // LOGIN
      
        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

       // AUTOMATION TAGS

        ExtentListener.getTest().info(
                "Step 2: Navigate to Automation Tags"
        );

        AutomationTags automation = new AutomationTags(driver);

        // ADMIN
   
        ExtentListener.getTest().info(
                "Step 3: Open Admin"
        );

        automation.ClickAdmin();
        
        // TOOLS
   
        ExtentListener.getTest().info(
                "Step 4: Open Tools"
        );

        automation.ClickTools();
        
        // USER TOOLS

        ExtentListener.getTest().info(
                "Step 5: Open User Tools"
        );

        automation.ClickUsersTools();

        // ADMIN POLICY


        ExtentListener.getTest().info(
                "Step 6: Open Admin Policy"
        );

        automation.ClickAdminPolicy();

        // AUTOMATION TAGS

        ExtentListener.getTest().info(
                "Step 7: Open Automation Tags"
        );

        automation.ClickAutomation();

        // GENERAL RULES
  
        ExtentListener.getTest().info(
                "Step 8: Open General Rules"
        );

        automation.ClickGeneralRules();

        // USER REPORTS
     
        ExtentListener.getTest().info(
                "Step 9: Configure User Reports"
        );

        automation.ClickUserReports();
        automation.ClickToggle1();

        Assert.assertTrue(
                automation.isDisplayedToogle1(),
                "User Reports toggle is not displayed"
        );

        // ROOM REPORTS
    
        ExtentListener.getTest().info(
                "Step 10: Configure Room Reports"
        );

        automation.ClickRoomReports();
        automation.ClickToggle2();

        Assert.assertTrue(
                automation.isDisplayedToogle2(),
                "Room Reports toggle is not displayed"
        );

        // DESK REPORTS
  
        ExtentListener.getTest().info(
                "Step 11: Configure Desk Reports"
        );

        automation.ClickDeskReports();
        automation.ClickToggle3();

        Assert.assertTrue(
                automation.isDisplayedToogle3(),
                "Desk Reports toggle is not displayed"
        );

        // COMPUTER REPORTS

        ExtentListener.getTest().info(
                "Step 12: Configure Computer Reports"
        );

        automation.ClickComputerReports();
        automation.ClickToggle4();

     
        // USER RULES
    
        ExtentListener.getTest().info(
                "Step 13: Configure User Rules"
        );

        automation.ClickUserRules();

        automation.ClickInviteUsers();
        automation.ClickImportUsers();
        automation.ClickToogle();

        automation.ClickCreateUsers();

        automation.ClickSuspendUsers();
        automation.ClickToggle5();

        automation.ClickUnlockUsers();
        automation.ClickToggle6();


        // ROOM RULES

        ExtentListener.getTest().info(
                "Step 14: Configure Room Rules"
        );

        automation.ClickRoomRules();
        automation.ClickMakeUnavailableRoom();


        // DESK RULES
     
        ExtentListener.getTest().info(
                "Step 15: Configure Desk Rules"
        );

        automation.ClickDeskRules();
        automation.ClickMakeUnavailableDesk();
        automation.ClickToggle7();


        // COMPUTER RULES
      
        ExtentListener.getTest().info(
                "Step 16: Configure Computer Rules"
        );

        automation.ClickComputerRules();
        automation.ClickMakeUnavailableComputer();
        automation.ClickToggle8();


       // UPDATE
      
        ExtentListener.getTest().info(
                "Step 17: Verify Update button is displayed"
        );

        Assert.assertTrue(
                automation.isDisplayedUpdated(),
                "Update button is not displayed"
        );


        ExtentListener.getTest().info(
                "Step 18: Update the Automation Tags configuration"
        );

        automation.ClickUpdate();


        // ACTUAL RESULT
   
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Automation Tags settings were configured for the available " +
                "General, User, Room, Desk and Computer rules, and the " +
                "Update action was performed."
        );
    }
}