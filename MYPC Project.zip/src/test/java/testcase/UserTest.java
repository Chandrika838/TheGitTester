package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.UserPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class UserTest extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to Users, open Invite Users, "
            + "enter the required user details and perform the Submit operation.")
    public void verifyUserSettings() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Users");
        ExtentListener.getTest().info("• Open Invite Users");
        ExtentListener.getTest().info("• Enter First Name");
        ExtentListener.getTest().info("• Enter Last Name");
        ExtentListener.getTest().info("• Verify Submit option is displayed");
        ExtentListener.getTest().info("• Click Submit");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to navigate to Invite Users, "
                + "enter the required First Name and Last Name, verify that the "
                + "Submit option is displayed and perform the Submit operation."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Users"
        );

        UserPage userPage = new UserPage(driver);

        userPage.clickAdmnMenu();
        userPage.clickUserMenu();

        ExtentListener.getTest().info(
                "Step 3: Open Invite Users"
        );

        userPage.clickInviteUsers();

        ExtentListener.getTest().info(
                "Step 4: Enter First Name"
        );

        userPage.enterFirstName(
                config.getFirstName()
        );

        ExtentListener.getTest().info(
                "Step 5: Enter Last Name"
        );

        userPage.enterLastName(
                config.getLastName()
        );

        ExtentListener.getTest().info(
                "Step 6: Verify Submit option is displayed"
        );

        Assert.assertTrue(
                userPage.isDisplayed(),
                "Submit is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 7: Click Submit"
        );

        userPage.clickSubmit();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to Invite Users, "
                + "entered the configured First Name and Last Name, verified that the "
                + "Submit option was displayed and performed the Submit operation."
        );
    }
}
