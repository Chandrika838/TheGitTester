package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.Guestuserpage;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

@Test(groups = "regression")
public class InvalidGuestUsers extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that the system displays the validation message when "
            + "an administrator attempts to create a Guest User with a blank User Name.")
    public void VerifyBlankUserName() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Guest Users");
        ExtentListener.getTest().info("• Open Add New Guest User");
        ExtentListener.getTest().info("• Leave User Name blank");
        ExtentListener.getTest().info("• Enter other valid Guest User details");
        ExtentListener.getTest().info("• Select User Tag and activation");
        ExtentListener.getTest().info("• Click Submit");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent Guest User creation when the User Name "
                + "is blank and display <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Guest Users and open Add New"
        );

        Guestuserpage guestUsers = new Guestuserpage(driver);

        guestUsers.ClickAdmin();
        guestUsers.ClickTools();
        guestUsers.ClickUsers();
        guestUsers.ClickGuestUsers();
        guestUsers.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave User Name blank"
        );

        guestUsers.enterName("");

        ExtentListener.getTest().info(
                "Step 4: Enter the remaining valid Guest User details"
        );

        guestUsers.enterPrefix(config.getUserprefix());
        guestUsers.enterNumberofFigures(config.getNumberoffigure());
        guestUsers.SelectCharacter(config.getCharacter());
        guestUsers.enterLength(config.getLength());
        guestUsers.SelectExpired(config.getExpried());
        guestUsers.enterNumberofperiods(config.getNumberofPeriod());

        ExtentListener.getTest().info(
                "Step 5: Click Add and configure Guest User options"
        );

        guestUsers.ClickAdd();
        guestUsers.SelectTags(config.getUsersTag());
        guestUsers.ClickCheckbox();

        Assert.assertTrue(
                guestUsers.isSelectedChedckbox(),
                "CheckBox is not Selected"
        );

        guestUsers.SelectActivation(config.getActivation());

        Assert.assertTrue(
                guestUsers.isDisplayedSubmit(),
                "Submit is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 6: Click Submit"
        );

        guestUsers.ClickSubmit();

        Assert.assertTrue(
                guestUsers.isBlankNameDisplayed(),
                "Blank Name is Not Displayed"
        );

        String actualMessage = guestUsers.getInvalidMessage();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Guest User creation was prevented because the User Name was left blank. "
                + "The system displayed <b>\"Invalid entry!\"</b> as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays the validation message when "
            + "the Guest User Prefix is left blank.")
    public void VerifyUserPerfixBlank() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Guest Users");
        ExtentListener.getTest().info("• Open Add New Guest User");
        ExtentListener.getTest().info("• Leave User Name and Prefix blank");
        ExtentListener.getTest().info("• Enter remaining Guest User details");
        ExtentListener.getTest().info("• Click Submit");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent Guest User creation when the required "
                + "User Name and Prefix fields are blank and display "
                + "<b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Guest Users and open Add New"
        );

        Guestuserpage guestUsers = new Guestuserpage(driver);

        guestUsers.ClickAdmin();
        guestUsers.ClickTools();
        guestUsers.ClickUsers();
        guestUsers.ClickGuestUsers();
        guestUsers.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave User Name and Prefix blank"
        );

        guestUsers.enterName("");
        guestUsers.enterPrefix("");

        ExtentListener.getTest().info(
                "Step 4: Enter the remaining Guest User details"
        );

        guestUsers.enterNumberofFigures(config.getNumberoffigure());
        guestUsers.SelectCharacter(config.getCharacter());
        guestUsers.enterLength(config.getLength());
        guestUsers.SelectExpired(config.getExpried());
        guestUsers.enterNumberofperiods(config.getNumberofPeriod());

        ExtentListener.getTest().info(
                "Step 5: Click Add and configure Guest User options"
        );

        guestUsers.ClickAdd();
        guestUsers.SelectTags(config.getUsersTag());
        guestUsers.ClickCheckbox();

        Assert.assertTrue(
                guestUsers.isSelectedChedckbox(),
                "CheckBox is not Selected"
        );

        guestUsers.SelectActivation(config.getActivation());

        Assert.assertTrue(
                guestUsers.isDisplayedSubmit(),
                "Submit is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 6: Click Submit"
        );

        guestUsers.ClickSubmit();

        Assert.assertTrue(
                guestUsers.isBlankNameDisplayed(),
                "Blank Name is Not Displayed"
        );

        String actualMessage = guestUsers.getInvalidMessage();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Guest User creation was prevented because the required fields "
                + "were left blank. The system displayed <b>\"Invalid entry!\"</b> "
                + "as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays the validation message when "
            + "required Guest User fields are left blank.")
    public void VerifyInvalidCerdential() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Guest Users");
        ExtentListener.getTest().info("• Open Add New Guest User");
        ExtentListener.getTest().info("• Leave User Name, Prefix and Number of Figures blank");
        ExtentListener.getTest().info("• Enter remaining Guest User details");
        ExtentListener.getTest().info("• Click Submit");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent Guest User creation when required "
                + "fields are blank and display <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Guest Users and open Add New"
        );

        Guestuserpage guestUsers = new Guestuserpage(driver);

        guestUsers.ClickAdmin();
        guestUsers.ClickTools();
        guestUsers.ClickUsers();
        guestUsers.ClickGuestUsers();
        guestUsers.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave required Guest User fields blank"
        );

        guestUsers.enterName("");
        guestUsers.enterPrefix("");
        guestUsers.enterNumberofFigures("");

        ExtentListener.getTest().info(
                "Step 4: Enter the remaining Guest User details"
        );

        guestUsers.SelectCharacter(config.getCharacter());
        guestUsers.enterLength(config.getLength());
        guestUsers.SelectExpired(config.getExpried());
        guestUsers.enterNumberofperiods(config.getNumberofPeriod());

        ExtentListener.getTest().info(
                "Step 5: Click Add and configure Guest User options"
        );

        guestUsers.ClickAdd();
        guestUsers.SelectTags(config.getUsersTag());
        guestUsers.ClickCheckbox();

        Assert.assertTrue(
                guestUsers.isSelectedChedckbox(),
                "CheckBox is not Selected"
        );

        guestUsers.SelectActivation(config.getActivation());

        Assert.assertTrue(
                guestUsers.isDisplayedSubmit(),
                "Submit is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 6: Click Submit"
        );

        guestUsers.ClickSubmit();

        Assert.assertTrue(
                guestUsers.isBlankNameDisplayed(),
                "Blank Name is Not Displayed"
        );

        String actualMessage = guestUsers.getInvalidMessage();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Guest User creation was prevented because required fields "
                + "were left blank. The system displayed <b>\"Invalid entry!\"</b> "
                + "as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays the validation message when "
            + "invalid characters are entered in the Guest User Prefix and "
            + "Number of Figures fields.")
    public void VerifyInvalidCharcter() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Guest Users");
        ExtentListener.getTest().info("• Open Add New Guest User");
        ExtentListener.getTest().info("• Leave User Name blank");
        ExtentListener.getTest().info("• Enter invalid characters in Prefix and Number of Figures");
        ExtentListener.getTest().info("• Click Submit");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent Guest User creation when invalid "
                + "characters are entered and display <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Guest Users and open Add New"
        );

        Guestuserpage guestUsers = new Guestuserpage(driver);

        guestUsers.ClickAdmin();
        guestUsers.ClickTools();
        guestUsers.ClickUsers();
        guestUsers.ClickGuestUsers();
        guestUsers.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Enter blank and invalid Guest User values"
        );

        guestUsers.enterName("");
        guestUsers.enterPrefix("1234");
        guestUsers.enterNumberofFigures("@@@@");

        ExtentListener.getTest().info(
                "Step 4: Enter the remaining Guest User details"
        );

        guestUsers.SelectCharacter(config.getCharacter());
        guestUsers.enterLength(config.getLength());
        guestUsers.SelectExpired(config.getExpried());
        guestUsers.enterNumberofperiods(config.getNumberofPeriod());

        ExtentListener.getTest().info(
                "Step 5: Click Add and configure Guest User options"
        );

        guestUsers.ClickAdd();
        guestUsers.SelectTags(config.getUsersTag());
        guestUsers.ClickCheckbox();

        Assert.assertTrue(
                guestUsers.isSelectedChedckbox(),
                "CheckBox is not Selected"
        );

        guestUsers.SelectActivation(config.getActivation());

        Assert.assertTrue(
                guestUsers.isDisplayedSubmit(),
                "Submit is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 6: Click Submit"
        );

        guestUsers.ClickSubmit();

        Assert.assertTrue(
                guestUsers.isBlankNameDisplayed(),
                "Blank Name is Not Displayed"
        );

        String actualMessage = guestUsers.getInvalidMessage();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Guest User creation was prevented. The system displayed "
                + "<b>\"Invalid entry!\"</b> as expected."
        );
    }
}

