package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.UsersTags;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class UserTagsTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to User Tags, "
            + "create a new User Tag using the configured tag name and "
            + "verify that the Submit option is displayed.")
    public void verifyAddUserTestCase() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Enable High Contrast");
        ExtentListener.getTest().info("• Navigate to Users Tools");
        ExtentListener.getTest().info("• Navigate to User Tags");
        ExtentListener.getTest().info("• Click Add New");
        ExtentListener.getTest().info("• Enter User Tag name");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify Submit option is displayed");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to navigate to User Tags, "
                + "enter the configured User Tag name, perform the Add operation "
                + "and verify that the Submit option is displayed."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());

        ExtentListener.getTest().info(
                "Step 2: Enable High Contrast"
        );

        loginPage.enableHighContrast();
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 3: Navigate to User Tags"
        );

        UsersTags Users = new UsersTags(driver);

        Users.ClickAdmin();
        Users.ClickTools();
        Users.ClickUsersTool();
        Users.ClickTags();

        ExtentListener.getTest().info(
                "Step 4: Click Add New"
        );

        Users.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 5: Enter User Tag name"
        );

        String tagName = config.getUsersTag();

        ExtentListener.getTest().info(
                "<b>User Tag Name:</b> " + tagName
        );

        Users.enterUsersTag(tagName);

        ExtentListener.getTest().info(
                "Step 6: Click Add"
        );

        Users.clickAdd();

        ExtentListener.getTest().info(
                "Step 7: Verify Submit option is displayed"
        );

        Assert.assertTrue(
                Users.isDisplayedAddSubmit(),
                "Submit is not Displayed"
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to User Tags, "
                + "entered the configured User Tag name, performed the Add operation "
                + "and verified that the Submit option was displayed."
        );
    }
}


