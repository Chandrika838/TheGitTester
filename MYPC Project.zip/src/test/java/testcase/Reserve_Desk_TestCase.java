package testcase;

import java.time.LocalDate;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.Reserve_DeskPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class Reserve_Desk_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that a user can navigate to Reserve Desk, select the required "
            + "booking details, configure Self Booking and proceed with the desk booking.")
    public void verifyAddDeskReserve() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Reserve Desk");
        ExtentListener.getTest().info("• Select Location");
        ExtentListener.getTest().info("• Verify Location is displayed");
        ExtentListener.getTest().info("• Select Booking Date");
        ExtentListener.getTest().info("• Enable Tool Tip");
        ExtentListener.getTest().info("• Verify Tool Tip is displayed");
        ExtentListener.getTest().info("• Select Start Time");
        ExtentListener.getTest().info("• Verify Start Time is displayed");
        ExtentListener.getTest().info("• Enable Drag and Drop");
        ExtentListener.getTest().info("• Enable Self Booking");
        ExtentListener.getTest().info("• Verify Self Booking is displayed");
        ExtentListener.getTest().info("• Click Book");
        ExtentListener.getTest().info("• Verify Book option is displayed");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The user should be able to select the required desk booking details, "
                + "configure the booking options and proceed with the booking."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                config.getEmail(),
                config.getPassword()
        );

        ExtentListener.getTest().info(
                "Step 2: Navigate to Reserve Desk"
        );

        Reserve_DeskPage deskPage =
                new Reserve_DeskPage(driver);

        deskPage.ClickReserve();
        deskPage.ClickDesk();

        ExtentListener.getTest().info(
                "Step 3: Select Location"
        );

        deskPage.SelectLocation(config.getLocation());

        Assert.assertTrue(
                deskPage.isDisplayedLocation(),
                "Location is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 4: Select Booking Date"
        );

        deskPage.selectDate(
                LocalDate.now().plusDays(1)
        );

        ExtentListener.getTest().info(
                "Step 5: Enable Tool Tip"
        );

        deskPage.ClickToolTip();

        Assert.assertTrue(
                deskPage.isDisplayedToolTip(),
                "Tool Tip is not Displayed"
        );

        ExtentListener.getTest().info(
                "Step 6: Select Start Time"
        );

        deskPage.SelectStartTime1(
                config.getStartTime1()
        );

        Assert.assertTrue(
                deskPage.isDisplayedStartTime1(),
                "Start Time is not Displayed"
        );

        ExtentListener.getTest().info(
                "Step 7: Enable Drag and Drop"
        );

        deskPage.ClickDragDrop();

        ExtentListener.getTest().info(
                "Step 8: Enable Self Booking"
        );

        deskPage.enableSelfBooking();

        Assert.assertTrue(
                deskPage.isDisplayedSelfBooking(),
                "Self Booking is not Displayed"
        );

        ExtentListener.getTest().info(
                "Step 9: Click Book"
        );

        deskPage.ClickBook();

        ExtentListener.getTest().info(
                "Step 10: Verify Book option is displayed"
        );

        Assert.assertTrue(
                deskPage.isDisplayedBook(),
                "Book is not Displayed"
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Reserve Desk page was accessed successfully. The configured "
                + "Location, Booking Date and Start Time were selected, Tool Tip, "
                + "Drag and Drop and Self Booking were configured, and the Book "
                + "action was performed successfully."
        );
    }
}