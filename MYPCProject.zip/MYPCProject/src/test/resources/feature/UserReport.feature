@regression
Feature: Room Report

  Scenario: Verify Room Report filters

    Given I open the application

    When I enter valid email

    And I enter valid password

    And I enable high contrast

    Then high contrast should be enabled

    When I click the login button

    When I click Reports

    When I click User Reports

    When I select the location

    Then the location dropdown should be displayed

    When I select the period

    Then the period dropdown should be displayed

    When I select the booking type

    Then the booking type dropdown should be displayed