package testcase.reports;

import org.testng.annotations.Test;

import testcase.BaseTest;
import adminpage.LoginPage;
import reports.DeskPage;
import automation.pages.utils.ConfigReader;

public class DeskTestCase extends BaseTest{

ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddDeskTest() {
		
	// creating a constructor for the login Page 
		
   LoginPage loginPage = new LoginPage(driver);
   
   loginPage.enterEmail(config.getEmail());
   loginPage.enterPassword(config.getPassword());
   loginPage.clickLogin();
   
   
// creating an constructor for UserTest Case 
   
   DeskPage desk = new DeskPage(driver);
   desk.ClickReport();
   desk.ClickDeskReport();
   desk.SelectLocation(config.getLocation());
   desk.SelectMonth(config.getperiod());
   desk.SelectBookingType(config.getBookingType());
}

}