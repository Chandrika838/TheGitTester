package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.OrganisationPage;
import automation.pages.utils.ExtentListener;

public class InvalidOrganisationTestCase extends BaseTest {

    @Test(description =
            "Verifies that Organisation settings display a validation message "
            + "when mandatory configuration is not provided.")
    public void verifyOrganisationMandatoryValidation() {

      
        ExtentListener.getTest().info(
                "<b>Scenarios Covered:</b>"
        );

        ExtentListener.getTest().info(
                "• Login with valid administrator credentials"
        );

        ExtentListener.getTest().info(
                "• Navigate to Organisation settings"
        );

        ExtentListener.getTest().info(
                "• Select configured language"
        );

        ExtentListener.getTest().info(
                "• Select configured time zone"
        );

        ExtentListener.getTest().info(
                "• Open Advanced Options"
        );

        ExtentListener.getTest().info(
                "• Leave the mandatory configuration incomplete"
        );

        ExtentListener.getTest().info(
                "• Click Submit"
        );

        ExtentListener.getTest().info(
                "• Verify Invalid entry validation message"
        );

        // =========================
        // EXPECTED RESULT
        // =========================

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The Organisation settings should not be submitted when " +
                "mandatory configuration is incomplete. The application " +
                "should display the 'Invalid entry!' validation message."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

      

        ExtentListener.getTest().info(
                "Step 2: Navigate to Organisation settings"
        );

        OrganisationPage organisationPage =
                new OrganisationPage(driver);

        organisationPage.clickAdminMenu();
        organisationPage.clickOrganisation();

       

        ExtentListener.getTest().info(
                "Step 3: Select the configured Organisation language"
        );

        organisationPage.SelectLanguage(
                config.getlanguage()
        );

        

        ExtentListener.getTest().info(
                "Step 4: Select the configured Organisation time zone"
        );

        organisationPage.selectTimeZone(
                config.gettimeZone()
        );

       

        ExtentListener.getTest().info(
                "Step 5: Open Advanced Options"
        );

        organisationPage.clickAdvancedOption();

      
        ExtentListener.getTest().info(
                "Step 6: Leave the mandatory configuration incomplete"
        );

       

        ExtentListener.getTest().info(
                "Step 7: Click Submit without completing mandatory configuration"
        );

        organisationPage.clickSubmit();

      

        ExtentListener.getTest().info(
                "Step 8: Verify Invalid entry validation message"
        );

        String actualMessage =
                organisationPage.getValidationMessage();

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Expected validation message was not displayed."
        );

     

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Organisation settings were not submitted because " +
                "the mandatory configuration was incomplete. The " +
                "'Invalid entry!' validation message was displayed successfully."
        );
    }
}