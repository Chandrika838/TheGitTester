package testcase;

import org.testng.annotations.Test;

import adminpage.DeskCopyProperties;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class DeskCopyPropertiesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can copy Desk properties "
            + "from a source desk to the selected location with the required settings.")
    public void verifyDesk() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Desk Copy Properties");
        ExtentListener.getTest().info("• Select the source desk");
        ExtentListener.getTest().info("• Select the target location");
        ExtentListener.getTest().info("• Enable required Desk properties");
        ExtentListener.getTest().info("• Configure Desk settings");
        ExtentListener.getTest().info("• Configure Default settings");
        ExtentListener.getTest().info("• Configure Preparation Time");
        ExtentListener.getTest().info("• Configure Check-in settings");
        ExtentListener.getTest().info("• Configure Check-in Tags");
        ExtentListener.getTest().info("• Perform Copy operation");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to select the source desk and target location, "
                + "enable the required Desk properties, configure the required settings, "
                + "and perform the Copy operation successfully."
        );

        // Step 1: Login
        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Step 2: Navigate to Desk Copy Properties
        ExtentListener.getTest().info(
                "Step 2: Navigate to Desk Copy Properties"
        );

        DeskCopyProperties desk = new DeskCopyProperties(driver);

        desk.ClickAdmin();
        desk.ClickTools();
        desk.ClickDesk();
        desk.ClickCopyProperties();

        // Step 3: Select Source Desk
        ExtentListener.getTest().info(
                "Step 3: Select the source Desk"
        );

        desk.SelectSource(config.getDeskName());

        // Step 4: Select Location
        ExtentListener.getTest().info(
                "Step 4: Select the target Location"
        );

        desk.SelectLocations(config.getLocations());

        // Step 5: Enable required properties
        ExtentListener.getTest().info(
                "Step 5: Enable Desk properties"
        );

        desk.enableCheckbox();

        // Step 6: Enable settings
        ExtentListener.getTest().info(
                "Step 6: Enable required Desk settings"
        );

        desk.enableSetting();

        // Step 7: Enable Default
        ExtentListener.getTest().info(
                "Step 7: Enable Default settings"
        );

        desk.enableDefault();

        // Step 8: Preparation Time
        ExtentListener.getTest().info(
                "Step 8: Enable Preparation Time"
        );

        desk.enablePrepartionTime();

        // Step 9: Check-in Settings
        ExtentListener.getTest().info(
                "Step 9: Enable Check-in Settings"
        );

        desk.enableCheckinSetting();

        // Step 10: Check-in Tags
        ExtentListener.getTest().info(
                "Step 10: Enable Check-in Tags"
        );

        desk.enableCheckinTags1();

        // Step 11: Copy
        ExtentListener.getTest().info(
                "Step 11: Click Copy to apply the selected Desk properties"
        );

        desk.ClickCopy();

        // Actual Result
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The source Desk and target Location were selected, the required "
                + "Desk properties and settings were enabled, and the Copy operation "
                + "was performed."
        );
    }
}
