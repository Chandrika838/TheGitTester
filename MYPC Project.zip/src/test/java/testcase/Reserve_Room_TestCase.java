package testcase;

import java.time.LocalDate;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.Reserve_RoomPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class Reserve_Room_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that a user can navigate to Reserve Room, select the required "
            + "booking details, configure booking options and proceed with the room booking.")
    public void verifyReserveRoom() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Reserve Room");
        ExtentListener.getTest().info("• Select Location");
        ExtentListener.getTest().info("• Verify Location is displayed");
        ExtentListener.getTest().info("• Select Booking Date");
        ExtentListener.getTest().info("• Enable Tool Tip");
        ExtentListener.getTest().info("• Select Start Time");
        ExtentListener.getTest().info("• Enable Drag and Drop");
        ExtentListener.getTest().info("• Enable Self Booking");
        ExtentListener.getTest().info("• Click Submit");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The user should be able to select the required room booking details, "
                + "configure the booking options and proceed with the room booking."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                config.getEmail(),
                config.getPassword()
        );

        ExtentListener.getTest().info(
                "Step 2: Navigate to Reserve Room"
        );

        Reserve_RoomPage reserve =
                new Reserve_RoomPage(driver);

        reserve.clickReserve();
        reserve.clickRoom();

        ExtentListener.getTest().info(
                "Step 3: Select Location"
        );

        reserve.SelectLocation(
                config.getLocation()
        );

        Assert.assertTrue(
                reserve.isDisplayedLocation(),
                "Location is not Selected"
        );

        ExtentListener.getTest().info(
                "Step 4: Select Booking Date"
        );

        reserve.selectDate(
                LocalDate.now().plusDays(1)
        );

        ExtentListener.getTest().info(
                "Step 5: Enable Tool Tip"
        );

        reserve.clickToolTip();

        ExtentListener.getTest().info(
                "Step 6: Select Start Time"
        );

        reserve.selectStartime(
                config.getstartTime()
        );

        ExtentListener.getTest().info(
                "Step 7: Enable Drag and Drop"
        );

        reserve.clickDragdrop();

        ExtentListener.getTest().info(
                "Step 8: Enable Self Booking"
        );

        reserve.enableSelfBooking();

        ExtentListener.getTest().info(
                "Step 9: Click Submit"
        );

        reserve.clickSubmit();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Reserve Room page was accessed successfully. The Location and "
                + "Booking Date were selected, Tool Tip, Drag and Drop and Self Booking "
                + "were configured, and the Submit action was performed."
        );
    }
}