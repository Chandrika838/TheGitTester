package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.UsersRoomPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class UsersRoomBookingRules extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to User Room Booking Rules, "
            + "configure the required room booking settings for all users and submit "
            + "the booking rule configuration.")
    public void VerifyAddUser() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to User Room Booking Rules");
        ExtentListener.getTest().info("• Select Rooms");
        ExtentListener.getTest().info("• Select All Users");
        ExtentListener.getTest().info("• Enable Access");
        ExtentListener.getTest().info("• Verify Access is selected");
        ExtentListener.getTest().info("• Configure Maximum Bookings Per Month");
        ExtentListener.getTest().info("• Verify Maximum Bookings Per Month");
        ExtentListener.getTest().info("• Configure Maximum Booking Duration");
        ExtentListener.getTest().info("• Verify Maximum Booking Duration");
        ExtentListener.getTest().info("• Configure Number of Bookings");
        ExtentListener.getTest().info("• Verify Number of Bookings");
        ExtentListener.getTest().info("• Configure Maximum Allowed Per Day");
        ExtentListener.getTest().info("• Verify Maximum Allowed Per Day");
        ExtentListener.getTest().info("• Configure Maximum Period to Book in Advance");
        ExtentListener.getTest().info("• Click Cancel");
        ExtentListener.getTest().info("• Click Submit");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to navigate to User Room Booking Rules, "
                + "select the required user scope, configure the room booking restrictions "
                + "and perform the Submit operation."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to User Room Booking Rules"
        );

        UsersRoomPage Users =
                new UsersRoomPage(driver);

        Users.ClickAdmin();
        Users.ClickTools();
        Users.ClicUser();
        Users.ClickBookingRules();
        Users.ClickRooms();

        ExtentListener.getTest().info(
                "Step 3: Select All Users"
        );

        Users.ClickAllusers();

        ExtentListener.getTest().info(
                "Step 4: Enable Access"
        );

        Users.ClickAccess();

        Assert.assertTrue(
                Users.isAccessSelected(),
                "Access is Not Selected"
        );

        ExtentListener.getTest().info(
                "Step 5: Configure Maximum Bookings Per Month"
        );

        Users.enablemaxiumBookingPerMonth(
                config.getMaximumPerMonth()
        );

        Assert.assertTrue(
                Users.isMaxiumBookingperMonthDisplayed(),
                "Maximum Booking per Month is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 6: Configure Maximum Booking Duration"
        );

        Users.enablemaxiumByDuration(
                config.getMaxiumBookingDuration()
        );

        Assert.assertTrue(
                Users.isMaxiumByDurationDisplayed(),
                "Maximum Booking Duration is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 7: Configure Number of Bookings"
        );

        Users.enableNumberofbooking(
                config.getMaxiumBookingDuration()
        );

        Assert.assertTrue(
                Users.isNumberofBookingDisplayed(),
                "Number of Booking is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 8: Configure Maximum Allowed Per Day"
        );

        Users.enableMaximumallowedperday(
                config.getMaximumPerMonth()
        );

        Assert.assertTrue(
                Users.MaxiumallowedperdayDisplayed(),
                "Maximum Allowed Per Day is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 9: Configure Maximum Period to Book in Advance"
        );

        Users.enableMaximunPeriodadvance(
                config.getmaximumperiodtobookinadvance()
        );

        ExtentListener.getTest().info(
                "Step 10: Click Cancel"
        );

        Users.ClickCancel();

        ExtentListener.getTest().info(
                "Step 11: Click Submit"
        );

        Users.ClickSubmit();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to User Room "
                + "Booking Rules, selected All Users, configured and verified the "
                + "required room booking settings, and performed the Cancel and "
                + "Submit actions."
        );
    }
}
