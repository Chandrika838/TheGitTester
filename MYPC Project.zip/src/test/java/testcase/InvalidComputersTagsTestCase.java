package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.ComputersTags;
import adminpage.LoginPage;
import automation.pages.utils.ExtentListener;

public class InvalidComputersTagsTestCase extends BaseTest {

    @Test(description =
            "Verifies that the system displays the appropriate validation message "
            + "when an administrator attempts to create a Computer Tag with a blank name.")
    public void VerifyBlankName() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Computer Tags");
        ExtentListener.getTest().info("• Open Add New Computer Tag");
        ExtentListener.getTest().info("• Leave the Computer Tag name blank");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify Submit button is displayed");
        ExtentListener.getTest().info("• Verify Invalid Message is displayed");
        ExtentListener.getTest().info("• Verify validation message is 'Invalid entry!'");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent the creation of a Computer Tag "
                + "with a blank name and should display the validation message "
                + "<b>\"Invalid entry!\"</b>."
        );

        // Step 1: Login
        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.enableHighContrast();
        loginPage.clickLogin();

        // Step 2: Navigate to Computer Tags
        ExtentListener.getTest().info(
                "Step 2: Navigate to Computer Tags"
        );

        ComputersTags comp = new ComputersTags(driver);

        comp.clickAdmin();
        comp.clickTools();
        comp.clickComputerTools();
        comp.ClickTags();

        // Step 3: Add New
        ExtentListener.getTest().info(
                "Step 3: Click Add New Computer Tag"
        );

        comp.ClickAddNew();

        // Step 4: Leave Tag Name Blank
        ExtentListener.getTest().info(
                "Step 4: Leave the Computer Tag name blank"
        );

        comp.enterComputerTags("");

        // Step 5: Click Add
        ExtentListener.getTest().info(
                "Step 5: Click Add with the Computer Tag name blank"
        );

        comp.clickAdd();

        // Step 6: Verify Submit
        ExtentListener.getTest().info(
                "Step 6: Verify Submit button is displayed"
        );

        Assert.assertTrue(
                comp.isDisplayedSubmit(),
                "Submit is not Displayed"
        );

        // Step 7: Verify Invalid Message
        ExtentListener.getTest().info(
                "Step 7: Verify Invalid Message is displayed"
        );

        Assert.assertTrue(
                comp.isInvalidMessageDisplayed(),
                "Invalid Message is not Displayed"
        );

        // Step 8: Verify Exact Validation Message
        ExtentListener.getTest().info(
                "Step 8: Verify validation message is 'Invalid entry!'"
        );

        String actualMessage = comp.getInvalidMessage();

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        // Actual Result
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Computer Tag name was left blank. The system displayed "
                + "the Invalid Message, and the validation message was verified "
                + "as <b>\"Invalid entry!\"</b> as expected."
        );
    }
}