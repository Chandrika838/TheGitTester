package Stepdefinitation;

import org.testng.Assert;

import automation.pages.utils.ConfigReader;
import hookclass.HookClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import reports.ComputerPage;

public class ComputerReportStepsDefination{

    private ComputerPage computerPage;
    private ConfigReader config;

    private void initComputerPage() {

        if (config == null) {
            config = new ConfigReader();
        }

        if (computerPage == null) {
            computerPage = new ComputerPage(HookClass.driver);
        }
    }

    @When("I click Reports for Computer Report")
    public void i_click_reports_for_computer_report() {

        initComputerPage();

        computerPage.ClickReport();
    }

    @When("I click Computer Report")
    public void i_click_computer_report() {

        initComputerPage();

        computerPage.ClickComputerReport();
    }

    @When("I select the computer report location")
    public void i_select_the_computer_report_location() {

        initComputerPage();

        computerPage.SelectLocation(config.getLocation());
    }

    @When("I select the computer report month")
    public void i_select_the_computer_report_month() {

        initComputerPage();

        computerPage.SelectMonth(config.getperiod());
    }

    @When("I select the computer report booking type")
    public void i_select_the_computer_report_booking_type() {

        initComputerPage();

        computerPage.SelectBookingType(config.getBookingType());
    }

    @When("I click the computer report pie chart")
    public void i_click_the_computer_report_pie_chart() {

        initComputerPage();

        computerPage.ClickPieChart();
    }

    @Then("the computer report pie chart should be displayed")
    public void the_computer_report_pie_chart_should_be_displayed() {

        initComputerPage();

        Assert.assertTrue(
            computerPage.isDisplayedPiechart(),
            "Pie chart is not displayed"
        );
    }
}