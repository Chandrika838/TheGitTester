package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.Sign_INPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class Sign_IN_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can open Profile Settings, "
            + "configure Theme, Language and Zoom preferences, and submit the settings.")
    public void verifySignIn() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Open Profile menu");
        ExtentListener.getTest().info("• Verify Settings option is displayed");
        ExtentListener.getTest().info("• Open Settings");
        ExtentListener.getTest().info("• Select Theme");
        ExtentListener.getTest().info("• Verify Theme is displayed");
        ExtentListener.getTest().info("• Select Language");
        ExtentListener.getTest().info("• Select Zoom level");
        ExtentListener.getTest().info("• Click Submit");
        ExtentListener.getTest().info("• Verify Submit option is displayed");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to open Profile Settings, "
                + "select the configured Theme, Language and Zoom preferences, "
                + "and submit the settings successfully."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Open the Profile menu"
        );

        Sign_INPage sign = new Sign_INPage(driver);

        sign.clickProfile();

        ExtentListener.getTest().info(
                "Step 3: Verify Settings option is displayed"
        );

        Assert.assertTrue(
                sign.isSettingDisplayed(),
                "Setting is not Displayed"
        );

        ExtentListener.getTest().info(
                "Step 4: Open Settings"
        );

        sign.ClickSetting();

        ExtentListener.getTest().info(
                "Step 5: Select Theme"
        );

        sign.selectTheme(
                config.getTheme()
        );

        ExtentListener.getTest().info(
                "Step 6: Verify Theme is displayed"
        );

        Assert.assertTrue(
                sign.isDisplayedTheme(),
                "Theme is not Displayed"
        );

        ExtentListener.getTest().info(
                "Step 7: Select Language"
        );

        sign.SelectLanguage(
                config.getlanguage()
        );

        ExtentListener.getTest().info(
                "Step 8: Select Zoom level"
        );

        sign.SelectZom(
                config.getZoom()
        );

        ExtentListener.getTest().info(
                "Step 9: Click Submit"
        );

        sign.clickSubmit();

        ExtentListener.getTest().info(
                "Step 10: Verify Submit option is displayed"
        );

        Assert.assertTrue(
                sign.isDisplayedSubmit(),
                "Submit is not Displayed"
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, opened Profile Settings, "
                + "selected the configured Theme, Language and Zoom preferences, "
                + "and performed the Submit operation."
        );
    }
}
