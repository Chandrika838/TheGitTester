package reports;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import base.BasePage;

public class RoomReport extends BasePage{

	public RoomReport(WebDriver driver) {
		
		super(driver);
		
	}
	
//  locators
	
	// Reports 
	
	private By Reports =
			By.xpath("//span[normalize-space()='Reports']");
	
	// Users
	
	private By Users=
			By.xpath("//span[normalize-space()='User Reports']");
	
	// locations 
	
	private By Location = 
			By.xpath("//select[@id='selectedLocationId']");
	
	private By period = 
			By.cssSelector("#period");
	
	
	private By BookingType=
			By.xpath("//select[@id='bookingType']");
	
	private By charts = 
			By.xpath("//body//app-root//button[2]");
	
	private By Charts =
			By.xpath("//body//app-root//button[2]");
	
	
	// methods 
	
	
	public void ClickReports() {

	        wait.until(ExpectedConditions.elementToBeClickable(Reports)).click();
	    }

	public void ClickUsers() {
		
	        wait.until(ExpectedConditions.elementToBeClickable(Users)).click();
	    }

	
	public void SelectLocation(String  value) {
		

		Select select = new Select(getElement(Location));
		select.selectByVisibleText(value);	 
	}
	
	
	public boolean isDisplayedLocation() {
		
		return isDisplayed(Location);
	}
	
	public void Selectperiod(String value) {
		
		Select select = new Select(getElement(period));
		select.selectByVisibleText(value);	 
	}
	
	public boolean isDisplayedperiod() {
		
		return isDisplayed(period);
	}
	
	public void SelectBookingType(String value) {
		Select select = new Select(getElement(BookingType));
		select.selectByVisibleText(value);	 
	}
	
	
	public boolean isDisplayedBookingType() {
		
		return isDisplayed(BookingType);
	}
	
}
