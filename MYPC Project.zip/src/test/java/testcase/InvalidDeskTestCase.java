package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.DeskPage;
import adminpage.LoginPage;
import automation.pages.utils.ExtentListener;

public class InvalidDeskTestCase extends BaseTest {

    @Test(description =
            "Verifies that the system displays the validation message when "
            + "an administrator attempts to create a Desk with invalid or blank details.")
    public void VerifyBlankName() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Desk");
        ExtentListener.getTest().info("• Open Add New Desk");
        ExtentListener.getTest().info("• Leave Desk Name blank");
        ExtentListener.getTest().info("• Enter valid location and desk settings");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent Desk creation when the Desk Name is blank "
                + "and display <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Desk and open Add New"
        );

        DeskPage desk = new DeskPage(driver);

        desk.ClickAdmin();
        desk.ClickDesk();
        desk.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave Desk Name blank"
        );

        desk.enterDeskName("");

        ExtentListener.getTest().info(
                "Step 4: Enter valid location and desk configuration"
        );

        desk.selectLocation(config.getLocation());
        desk.ClickAdvanceOption2();
        desk.enterDefaultDuration(config.getDuration());
        desk.selectPrepartion(config.getPrepration());
        desk.enableCheckInRequired();

        ExtentListener.getTest().info(
                "Step 5: Click Add"
        );

        desk.ClickAdd();

        ExtentListener.getTest().info(
                "Step 6: Verify validation message"
        );

        String actualMessage = desk.getInvalidMessage();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Desk creation was prevented because the Desk Name was left blank. "
                + "The system displayed <b>\"Invalid entry!\"</b> as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays the validation message when "
            + "an administrator attempts to create a Desk with a blank Desk Name "
            + "and blank Default Duration.")
    public void VerfiyInvalidCerdentials() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Desk");
        ExtentListener.getTest().info("• Open Add New Desk");
        ExtentListener.getTest().info("• Leave Desk Name blank");
        ExtentListener.getTest().info("• Leave Default Duration blank");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent Desk creation when required fields are blank "
                + "and display <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Desk and open Add New"
        );

        DeskPage desk = new DeskPage(driver);

        desk.ClickAdmin();
        desk.ClickDesk();
        desk.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave Desk Name blank"
        );

        desk.enterDeskName("");

        ExtentListener.getTest().info(
                "Step 4: Enter location and leave Default Duration blank"
        );

        desk.selectLocation(config.getLocation());
        desk.ClickAdvanceOption2();
        desk.enterDefaultDuration("");
        desk.selectPrepartion(config.getPrepration());
        desk.enableCheckInRequired();

        ExtentListener.getTest().info(
                "Step 5: Click Add"
        );

        desk.ClickAdd();

        ExtentListener.getTest().info(
                "Step 6: Verify validation message"
        );

        String actualMessage = desk.getInvalidMessage();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Desk creation was prevented because the Desk Name and Default Duration "
                + "were left blank. The system displayed <b>\"Invalid entry!\"</b> as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays the validation message when "
            + "an administrator attempts to create a Desk without providing a valid Desk Name.")
    public void VerifyPrepartion() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Desk");
        ExtentListener.getTest().info("• Open Add New Desk");
        ExtentListener.getTest().info("• Leave Desk Name blank");
        ExtentListener.getTest().info("• Enter preparation and other valid settings");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent Desk creation when the Desk Name is blank "
                + "and display <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Desk and open Add New"
        );

        DeskPage desk = new DeskPage(driver);

        desk.ClickAdmin();
        desk.ClickDesk();
        desk.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave Desk Name blank"
        );

        desk.enterDeskName("");

        ExtentListener.getTest().info(
                "Step 4: Enter location, duration, preparation and Check-In settings"
        );

        desk.selectLocation(config.getLocation());
        desk.ClickAdvanceOption2();
        desk.enterDefaultDuration(config.getDuration());
        desk.selectPrepartion(config.getPrepration());
        desk.enableCheckInRequired();

        ExtentListener.getTest().info(
                "Step 5: Click Add"
        );

        desk.ClickAdd();

        ExtentListener.getTest().info(
                "Step 6: Verify validation message"
        );

        String actualMessage = desk.getInvalidMessage();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Desk creation was prevented because the Desk Name was left blank. "
                + "The system displayed <b>\"Invalid entry!\"</b> as expected."
        );
    }
}


