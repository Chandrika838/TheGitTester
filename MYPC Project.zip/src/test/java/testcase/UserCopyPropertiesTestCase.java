package testcase;

import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.UserCopyProperties;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class UserCopyPropertiesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to User Copy Properties, "
            + "select the source user, configure the required user properties and "
            + "perform the Copy operation.")
    public void verifyAddUsers() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to User Copy Properties");
        ExtentListener.getTest().info("• Select Source User");
        ExtentListener.getTest().info("• Enable User Tags");
        ExtentListener.getTest().info("• Enable User Properties");
        ExtentListener.getTest().info("• Enable User Settings");
        ExtentListener.getTest().info("• Enable User Role");
        ExtentListener.getTest().info("• Enable Tag Settings");
        ExtentListener.getTest().info("• Enable Replace option");
        ExtentListener.getTest().info("• Click Copy");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to select the source user, "
                + "configure the required user properties and perform the Copy operation."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to User Copy Properties"
        );

        UserCopyProperties users =
                new UserCopyProperties(driver);

        users.clickAdmin();
        users.clickTools();
        users.clickUsers();
        users.clickCopyProperties();

        ExtentListener.getTest().info(
                "Step 3: Select Source User"
        );

        users.enterSource(
                config.getsourceuser()
        );

        ExtentListener.getTest().info(
                "Step 4: Enable User Tags"
        );

        users.enableTags();

        ExtentListener.getTest().info(
                "Step 5: Enable User Properties"
        );

        users.enableTags1();

        ExtentListener.getTest().info(
                "Step 6: Enable User Settings"
        );

        users.enableTags2();

        ExtentListener.getTest().info(
                "Step 7: Enable User Role"
        );

        users.enableTags3();
        users.enableUserRole();

        ExtentListener.getTest().info(
                "Step 8: Enable Tag Settings"
        );

        users.enableTagsSetting();

        ExtentListener.getTest().info(
                "Step 9: Enable Replace option"
        );

        users.enableReplace();

        ExtentListener.getTest().info(
                "Step 10: Click Copy"
        );

        users.clickCopy();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to User Copy "
                + "Properties, selected the configured Source User, enabled the required "
                + "user properties and settings, and performed the Copy operation."
        );
    }
}
