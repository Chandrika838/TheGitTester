package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.Desk_Tags;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class DeskTags_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can create a new Desk Tag "
            + "using a valid Desk Tag name.")
    public void verifyDeskTags() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Desk Tags");
        ExtentListener.getTest().info("• Open Add New Desk Tag");
        ExtentListener.getTest().info("• Enter a valid Desk Tag name");
        ExtentListener.getTest().info("• Add the Desk Tag");
        ExtentListener.getTest().info("• Verify Submit button is displayed");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to navigate to Desk Tags, "
                + "enter a valid Desk Tag name, add the tag, and the Submit "
                + "button should be displayed."
        );

        // Step 1: Login
        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.enableHighContrast();
        loginPage.clickLogin();

        // Step 2: Navigate to Desk Tags
        ExtentListener.getTest().info(
                "Step 2: Navigate to Desk Tags"
        );

        Desk_Tags deskTags = new Desk_Tags(driver);

        deskTags.ClickAdmin();
        deskTags.ClickTools();
        deskTags.ClickDesk();
        deskTags.ClickTags();

        // Step 3: Add New
        ExtentListener.getTest().info(
                "Step 3: Click Add New to create a Desk Tag"
        );

        deskTags.ClickAddNew();

        // Step 4: Enter Desk Tag
        String tagName = config.getDeskTagName();

        ExtentListener.getTest().info(
                "<b>Step 4: Enter Desk Tag Name:</b> " + tagName
        );

        deskTags.enterDeskTags(tagName);

        // Step 5: Add Desk Tag
        ExtentListener.getTest().info(
                "Step 5: Click Add to add the Desk Tag"
        );

        deskTags.clickAdd();

        // Step 6: Verify Submit
        ExtentListener.getTest().info(
                "Step 6: Verify Submit button is displayed"
        );

        Assert.assertTrue(
                deskTags.isDisplayedSubmit(),
                "Submit is not Displayed"
        );

        // Actual Result
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Desk Tag page was opened, the Desk Tag name was entered, "
                + "the Add operation was performed, and the Submit button "
                + "was displayed as expected."
        );
    }
}