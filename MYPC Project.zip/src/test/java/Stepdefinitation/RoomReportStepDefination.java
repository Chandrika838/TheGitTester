package Stepdefinitation;

import org.testng.Assert;

import automation.pages.utils.ConfigReader;
import hookclass.HookClass;
import reports.RoomReport;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RoomReportStepDefination {

    private RoomReport roomReport;
    private ConfigReader config;

    private void initRoomReportPage() {

        if (config == null) {
            config = new ConfigReader();
        }

        if (roomReport == null) {
            roomReport = new RoomReport(HookClass.driver);
        }
    }

    @When("I click Reports")
    public void i_click_reports() {

        initRoomReportPage();

        roomReport.ClickReports();
    }

    @When("I click User Reports")
    public void i_click_user_reports() {

        initRoomReportPage();

        roomReport.ClickUsers();
    }

    @When("I select the location")
    public void i_select_the_location() {

        initRoomReportPage();

        roomReport.SelectLocation(config.getLocation());
    }

    @Then("the location dropdown should be displayed")
    public void the_location_dropdown_should_be_displayed() {

        initRoomReportPage();

        Assert.assertTrue(
            roomReport.isDisplayedLocation(),
            "Location dropdown is not displayed"
        );
    }

    @When("I select the period")
    public void i_select_the_period() {

        initRoomReportPage();

        roomReport.Selectperiod(config.getperiod());
    }

    @Then("the period dropdown should be displayed")
    public void the_period_dropdown_should_be_displayed() {

        initRoomReportPage();

        Assert.assertTrue(
            roomReport.isDisplayedperiod(),
            "Period dropdown is not displayed"
        );
    }

    @When("I select the booking type")
    public void i_select_the_booking_type() {

        initRoomReportPage();

        roomReport.SelectBookingType(config.getBookingType());
    }

    @Then("the booking type dropdown should be displayed")
    public void the_booking_type_dropdown_should_be_displayed() {

        initRoomReportPage();

        Assert.assertTrue(
            roomReport.isDisplayedBookingType(),
            "Booking Type dropdown is not displayed"
        );
    }
}