package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.Guestuserpage;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class GuestUser extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can create a Guest User by configuring "
            + "guest user details, character settings, expiration, activation and submission.")
    public void VerifyAddGuestUsers() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Guest Users");
        ExtentListener.getTest().info("• Open Add New Guest User");
        ExtentListener.getTest().info("• Enter Guest User Name");
        ExtentListener.getTest().info("• Configure User Prefix");
        ExtentListener.getTest().info("• Configure Number of Figures");
        ExtentListener.getTest().info("• Select Character Type");
        ExtentListener.getTest().info("• Configure Guest User Length");
        ExtentListener.getTest().info("• Configure Expiration");
        ExtentListener.getTest().info("• Configure Number of Periods");
        ExtentListener.getTest().info("• Enable Guest User option");
        ExtentListener.getTest().info("• Configure Activation");
        ExtentListener.getTest().info("• Submit Guest User configuration");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to configure the required Guest User "
                + "details, select the required options, verify the checkbox and "
                + "Submit button, and perform the Submit operation successfully."
        );

        // Step 1: Login
        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Step 2: Navigate to Guest Users
        ExtentListener.getTest().info(
                "Step 2: Navigate to Guest Users"
        );

        Guestuserpage GuestUsers = new Guestuserpage(driver);

        GuestUsers.ClickAdmin();
        GuestUsers.ClickTools();
        GuestUsers.ClickUsers();
        GuestUsers.ClickGuestUsers();

        // Step 3: Add New
        ExtentListener.getTest().info(
                "Step 3: Click Add New Guest User"
        );

        GuestUsers.ClickAddNew();

        // Step 4: Enter Name
        ExtentListener.getTest().info(
                "Step 4: Enter Guest User Name"
        );

        GuestUsers.enterName(config.getName());

        // Step 5: User Prefix
        ExtentListener.getTest().info(
                "Step 5: Configure User Prefix"
        );

        GuestUsers.enterPrefix(config.getUserprefix());

        // Step 6: Number of Figures
        ExtentListener.getTest().info(
                "Step 6: Configure Number of Figures"
        );

        GuestUsers.enterNumberofFigures(config.getNumberoffigure());

        // Step 7: Character
        ExtentListener.getTest().info(
                "Step 7: Select Character Type"
        );

        GuestUsers.SelectCharacter(config.getCharacter());

        // Step 8: Length
        ExtentListener.getTest().info(
                "Step 8: Configure Guest User Length"
        );

        GuestUsers.enterLength(config.getLength());

        // Step 9: Expiration
        ExtentListener.getTest().info(
                "Step 9: Configure Expiration"
        );

        GuestUsers.SelectExpired(config.getExpried());

        // Step 10: Number of Periods
        ExtentListener.getTest().info(
                "Step 10: Configure Number of Periods"
        );

        GuestUsers.enterNumberofperiods(config.getNumberofPeriod());

        // Step 11: Checkbox
        ExtentListener.getTest().info(
                "Step 11: Enable Guest User option"
        );

        GuestUsers.ClickCheckbox();

        Assert.assertTrue(
                GuestUsers.isSelectedChedckbox(),
                "CheckBox is not Selected"
        );

        // Step 12: Activation
        ExtentListener.getTest().info(
                "Step 12: Configure Activation"
        );

        GuestUsers.SelectActivation(config.getActivation());

        // Step 13: Submit verification
        ExtentListener.getTest().info(
                "Step 13: Verify Submit button is displayed"
        );

        Assert.assertTrue(
                GuestUsers.isDisplayedSubmit(),
                "Submit button is not displayed"
        );

        // Step 14: Submit
        ExtentListener.getTest().info(
                "Step 14: Submit Guest User configuration"
        );

        GuestUsers.ClickSubmit();

        // Actual Result
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Guest User details and required configuration options were "
                + "entered, the checkbox was selected and verified, the Activation "
                + "option was configured, and the Submit button was displayed. "
                + "The Submit operation was performed."
        );
    }
}
