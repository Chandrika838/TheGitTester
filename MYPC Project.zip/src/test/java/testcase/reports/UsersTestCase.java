package testcase.reports;


import org.testng.Assert;
import org.testng.annotations.Test;

import testcase.BaseTest;
import adminpage.LoginPage;
import reports.UsersPage;
import automation.pages.utils.ConfigReader;

public class UsersTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddUserTest() {
		
	// creating a constructor for the login Page 
		
   LoginPage loginPage = new LoginPage(driver);
   
   loginPage.enterEmail(config.getEmail());
   loginPage.enterPassword(config.getPassword());
   loginPage.clickLogin();
   
   
   // creating an constructor for UserTest Case 
   
   UsersPage user = new UsersPage(driver);
   
   user.ClickReport();
   
   user.ClickUserReport();
   
   user.SelectLocation(config.getLocation());
   
   user.SelectMonth(config.getperiod());
   
   user.SelectBookingType(config.getBookingType());
   
   user.ClickPieChart();
   
   Assert.assertTrue(user.isPieChartDisplayed(),"Pie Chart is Not Displayed ");
   
	}
}
