package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.OrganisationPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class Organisation extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can configure Organisation settings "
            + "including Time Zone, Authentication, Tooltip and Resource options.")
    public void verifyOrganisationSettings() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Organisation settings");
        ExtentListener.getTest().info("• Select Time Zone");
        ExtentListener.getTest().info("• Verify Time Zone is displayed");
        ExtentListener.getTest().info("• Open Advanced Options");
        ExtentListener.getTest().info("• Enable Authentication options");
        ExtentListener.getTest().info("• Enable Booking Tooltip and Username options");
        ExtentListener.getTest().info("• Enable Room, Desk and PC resource options");
        ExtentListener.getTest().info("• Verify Submit button is displayed");
        ExtentListener.getTest().info("• Save Organisation settings");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The configured Organisation settings should be selected successfully, "
                + "the Submit button should be displayed, and the settings should be saved."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                config.getEmail(),
                config.getPassword()
        );

        ExtentListener.getTest().info(
                "Step 2: Navigate to Organisation settings"
        );

        OrganisationPage admin = new OrganisationPage(driver);

        admin.clickAdminMenu();
        admin.clickOrganisation();

        ExtentListener.getTest().info(
                "Step 3: Select the configured Time Zone"
        );

        admin.selectTimeZone(config.gettimeZone());

        ExtentListener.getTest().info(
                "Step 4: Verify Time Zone is displayed"
        );

        Assert.assertTrue(
                admin.isTimeZoneDisplayed(),
                "Time Zone is not Displayed"
        );

        ExtentListener.getTest().info(
                "Step 5: Open Advanced Options"
        );

        admin.clickAdvancedOption();

        ExtentListener.getTest().info(
                "Step 6: Enable Authentication options"
        );

        String[] checkBoxIds = {
                "allowAuthRezzervi",
                "allowAuthGoogle",
                "allowAuthMicrosoft",
                "allowAuthEntraID"
        };

        for (String id : checkBoxIds) {
            admin.enableCheckBox(id);
        }

        ExtentListener.getTest().info(
                "Step 7: Enable Booking Tooltip and Username options"
        );

        admin.enableCheckBox("showBookingTooltipForOthers");
        admin.enableCheckBox("showUsername");

        ExtentListener.getTest().info(
                "Step 8: Enable Room, Desk and PC resource options"
        );

        String[] resources = {
                "showRoom",
                "showDesk",
                "showPc"
        };

        for (String id : resources) {
            admin.enableCheckBox(id);
        }

        ExtentListener.getTest().info(
                "Step 9: Verify Submit button is displayed"
        );

        Assert.assertTrue(
                admin.isDisplayedSubmit(),
                "Submit is not Displayed"
        );

        ExtentListener.getTest().info(
                "Step 10: Save Organisation settings"
        );

        admin.clickSubmit();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Organisation settings were configured successfully. The Time Zone "
                + "was verified, the selected Authentication, Tooltip, Username and "
                + "Resource options were enabled, and the Submit action was performed."
        );
    }
}