package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.DeskProfile;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class DeskProfileTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can create a Desk Profile "
            + "using valid User Tags, Computer Tags and profile credentials.")
    public void verifyAddDesk() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Desk Profile");
        ExtentListener.getTest().info("• Open Add New Desk Profile");
        ExtentListener.getTest().info("• Select User Tags");
        ExtentListener.getTest().info("• Select Computer Tags");
        ExtentListener.getTest().info("• Submit Desk Profile configuration");
        ExtentListener.getTest().info("• Verify Continue option");
        ExtentListener.getTest().info("• Enter Context");
        ExtentListener.getTest().info("• Enter Username");
        ExtentListener.getTest().info("• Enter Password");
        ExtentListener.getTest().info("• Submit the Desk Profile");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to create a Desk Profile by selecting "
                + "the required User Tags and Computer Tags, entering the required "
                + "profile credentials, and submitting the configuration successfully."
        );

        // Step 1: Login
        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Step 2: Navigate to Desk Profile
        ExtentListener.getTest().info(
                "Step 2: Navigate to Desk Profile"
        );

        DeskProfile Deskp = new DeskProfile(driver);

        Deskp.ClickAdmin();
        Deskp.ClickTools();
        Deskp.Clickcomputers();
        Deskp.Clickdeskprofile();

        // Step 3: Add New
        ExtentListener.getTest().info(
                "Step 3: Click Add New Desk Profile"
        );

        Deskp.ClickAddnew();

        // Step 4: Select User Tags
        ExtentListener.getTest().info(
                "Step 4: Select User Tags"
        );

        Deskp.SelectUsertags(config.getUsersTag());

        Assert.assertTrue(
                Deskp.isDisplayed(),
                "User Tags is not displayed"
        );

        // Step 5: Select Computer Tags
        ExtentListener.getTest().info(
                "Step 5: Select Computer Tags"
        );

        Deskp.SelectComputerstags(config.getComputerTags());

        Assert.assertTrue(
                Deskp.isComputerDisplayed(),
                "Computer Tags is not displayed"
        );

        // Step 6: Submit
        ExtentListener.getTest().info(
                "Step 6: Submit Desk Profile configuration"
        );

        Deskp.ClickSubmit();

        Assert.assertTrue(
                Deskp.isContinueDisplayed(),
                "Continue is not displayed"
        );

        // Step 7: Enter Context
        ExtentListener.getTest().info(
                "Step 7: Enter Context"
        );

        Deskp.enternameContext(config.getContext());

        // Step 8: Enter Username
        ExtentListener.getTest().info(
                "Step 8: Enter Username"
        );

        Deskp.enternameUsername(config.getUsername());

        // Step 9: Enter Password
        ExtentListener.getTest().info(
                "Step 9: Enter Password"
        );

        Deskp.enternamePassword(config.getPassword1());

        // Step 10: Final Submit
        ExtentListener.getTest().info(
                "Step 10: Perform the final Submit operation"
        );

        Deskp.ClickSubmit();

        // Actual Result
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Desk Profile configuration was opened, the required User Tags "
                + "and Computer Tags were selected and verified, the Continue option "
                + "was displayed, and the required profile credentials were entered. "
                + "The final Submit operation was performed."
        );
    }
}
