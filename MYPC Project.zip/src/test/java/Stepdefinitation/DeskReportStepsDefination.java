package Stepdefinitation;

import automation.pages.utils.ConfigReader;
import hookclass.HookClass;
import io.cucumber.java.en.When;
import reports.DeskPage;

public class DeskReportStepsDefination {

    private DeskPage deskPage;
    private ConfigReader config;

    private void initDeskPage() {

        if (config == null) {
            config = new ConfigReader();
        }

        if (deskPage == null) {
            deskPage = new DeskPage(HookClass.driver);
        }
    }

    @When("I click Reports for Desk Report")
    public void i_click_reports_for_desk_report() {

        initDeskPage();

        deskPage.ClickReport();
    }

    @When("I click Desk Report")
    public void i_click_desk_report() {

        initDeskPage();

        deskPage.ClickDeskReport();
    }

    @When("I select the desk report location")
    public void i_select_the_desk_report_location() {

        initDeskPage();

        deskPage.SelectLocation(config.getLocation());
    }

    @When("I select the desk report month")
    public void i_select_the_desk_report_month() {

        initDeskPage();

        deskPage.SelectMonth(config.getperiod());
    }

    @When("I select the desk report booking type")
    public void i_select_the_desk_report_booking_type() {

        initDeskPage();

        deskPage.SelectBookingType(config.getBookingType());
    }
}