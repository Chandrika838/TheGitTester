package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.RoomTags;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class RoomTags_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to Room Tags, "
            + "add a new Room Tag using the configured tag name and proceed with the Add operation.")
    public void verifyRoomTags() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Room Tags");
        ExtentListener.getTest().info("• Click Add New");
        ExtentListener.getTest().info("• Enter Room Tag name");
        ExtentListener.getTest().info("• Click Add");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to navigate to Room Tags, "
                + "enter a valid Room Tag name and perform the Add operation."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Room Tags"
        );

        RoomTags roomTags = new RoomTags(driver);

        roomTags.ClickAdmin();
        roomTags.ClickTools();
        roomTags.ClickRoom();
        roomTags.ClickTags();

        ExtentListener.getTest().info(
                "Step 3: Click Add New"
        );

        roomTags.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 4: Enter Room Tag name"
        );

        String tagName = config.getRoomTags();

        ExtentListener.getTest().info(
                "<b>Room Tag Name:</b> " + tagName
        );

        roomTags.enterRoomTags(tagName);

        ExtentListener.getTest().info(
                "Step 5: Click Add"
        );

        roomTags.clickAdd();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to Room Tags, "
                + "entered the configured Room Tag name and performed the Add operation."
        );
    }
}

