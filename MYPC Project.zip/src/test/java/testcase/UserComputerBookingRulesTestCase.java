package testcase;

import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.UserComputerBookingRules;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class UserComputerBookingRulesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to User Computer Booking Rules, "
            + "select Automation Tags, configure computer booking restrictions and "
            + "submit the booking rule settings.")
    public void VerifyComputer() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to User Computer Booking Rules");
        ExtentListener.getTest().info("• Select Automation Tags");
        ExtentListener.getTest().info("• Enable Access");
        ExtentListener.getTest().info("• Configure Maximum Bookings Per Month");
        ExtentListener.getTest().info("• Configure Maximum Booking Duration");
        ExtentListener.getTest().info("• Configure Bookings Per Day");
        ExtentListener.getTest().info("• Configure Booking Allowed Per Day");
        ExtentListener.getTest().info("• Configure Maximum Period to Book in Advance");
        ExtentListener.getTest().info("• Configure Extension settings");
        ExtentListener.getTest().info("• Configure Auto Extension");
        ExtentListener.getTest().info("• Configure Maximum Extension Time");
        ExtentListener.getTest().info("• Configure Number of Extensions");
        ExtentListener.getTest().info("• Click Submit");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to configure the User Computer "
                + "Booking Rules for the selected Automation Tags and submit the "
                + "configured booking rule settings."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to User Computer Booking Rules"
        );

        UserComputerBookingRules comp =
                new UserComputerBookingRules(driver);

        comp.ClickAdmin();
        comp.ClickTools();
        comp.ClickUserTools();
        comp.ClickBookingRules();
        comp.ClickComputers();

        ExtentListener.getTest().info(
                "Step 3: Select Automation Tags"
        );

        comp.clickAutomationTags();

        ExtentListener.getTest().info(
                "Step 4: Enable Access"
        );

        comp.ClickAccess();
        comp.enableToogle();

        ExtentListener.getTest().info(
                "Step 5: Configure Maximum Bookings Per Month"
        );

        comp.clickMaxmiumBookingPerMonth();
        comp.enableInput(
                config.getMaximumPerMonth()
        );

        ExtentListener.getTest().info(
                "Step 6: Configure Maximum Booking Duration"
        );

        comp.ClickBookingDuration();
        comp.enableInput1(
                config.getMaxiumBookingDuration()
        );

        ExtentListener.getTest().info(
                "Step 7: Configure Bookings Per Day"
        );

        comp.ClickBookingPerDay();
        comp.enableInput2(
                config.getBookingPerDay()
        );

        ExtentListener.getTest().info(
                "Step 8: Configure Booking Allowed Per Day"
        );

        comp.ClickBookingAllowedPerDay();
        comp.enableInput3(
                config.getBookingAllowedPerDay()
        );

        ExtentListener.getTest().info(
                "Step 9: Configure Maximum Period to Book in Advance"
        );

        comp.ClickMaxmiumPeriodToBookinAdvance();
        comp.enableInput4(
                config.getmaximumperiodtobookinadvance()
        );

        ExtentListener.getTest().info(
                "Step 10: Configure Extension Settings"
        );

        comp.ClickExtend();
        comp.enableToogle1();

        ExtentListener.getTest().info(
                "Step 11: Enable Auto Extension"
        );

        comp.ClickAutoExtend();
        comp.enableToogle2();

        ExtentListener.getTest().info(
                "Step 12: Configure Maximum Extension Time"
        );

        comp.ClickMaxmiumExtendTime();
        comp.ClickToogle3();

        ExtentListener.getTest().info(
                "Step 13: Configure Number of Extensions"
        );

        comp.clickNumberofExtension();
        comp.ClickToogle4();

        ExtentListener.getTest().info(
                "Step 14: Click Submit"
        );

        comp.ClickSubmit();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to User Computer "
                + "Booking Rules, selected Automation Tags, configured the required "
                + "computer booking and extension settings, and performed the Submit operation."
        );
    }
}

