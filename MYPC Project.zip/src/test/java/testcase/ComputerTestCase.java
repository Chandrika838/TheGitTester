package testcase;

import org.testng.annotations.Test;

import adminpage.ComputerPage;
import adminpage.LoginPage;
import automation.pages.utils.ExtentListener;

public class ComputerTestCase extends BaseTest {

    @Test(description =
            "Verifies that an administrator can add a new computer with valid "
            + "computer details, location, advanced settings and computer tags.")
    public void verifyAddComputer() {

        // =========================
        // SCENARIOS COVERED
        // =========================

        ExtentListener.getTest().info(
                "<b>Scenarios Covered:</b>"
        );

        ExtentListener.getTest().info(
                "• Login with valid administrator credentials"
        );

        ExtentListener.getTest().info(
                "• Navigate to Computers"
        );

        ExtentListener.getTest().info(
                "• Open Add New Computer"
        );

        ExtentListener.getTest().info(
                "• Enter Computer Name and Computer ID"
        );

        ExtentListener.getTest().info(
                "• Select Computer Location"
        );

        ExtentListener.getTest().info(
                "• Configure Advanced Options"
        );

        ExtentListener.getTest().info(
                "• Configure No-Show Wait Time and Warning Levels"
        );

        ExtentListener.getTest().info(
                "• Configure Logging Level"
        );

        ExtentListener.getTest().info(
                "• Configure Welcome and AUP Messages"
        );

        ExtentListener.getTest().info(
                "• Configure Inactivity and Lock Timeout"
        );

        ExtentListener.getTest().info(
                "• Configure Automatic Reboot and Shutdown"
        );

        ExtentListener.getTest().info(
                "• Add and select Computer Tags"
        );

        ExtentListener.getTest().info(
                "• Add the Computer configuration"
        );


        // =========================
        // EXPECTED RESULT
        // =========================

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to enter valid computer details, "
                + "select the required location, configure advanced settings "
                + "and tags, and perform the Add Computer operation successfully."
        );


        // =========================
        // LOGIN
        // =========================

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();


        // =========================
        // COMPUTER PAGE
        // =========================

        ExtentListener.getTest().info(
                "Step 2: Navigate to Computers"
        );

        ComputerPage computerPage = new ComputerPage(driver);

        computerPage.ClickAdmin();

        computerPage.ClickComputers();


        ExtentListener.getTest().info(
                "Step 3: Click Add New Computer"
        );

        computerPage.ClickAddNew();


        ExtentListener.getTest().info(
                "Step 4: Enter Computer Name"
        );

        computerPage.enterComputerName(
                config.getComputerName()
        );


        ExtentListener.getTest().info(
                "Step 5: Enter Computer ID"
        );

        computerPage.enterComputerID(
                config.getComputerID()
        );

        ExtentListener.getTest().info(
                "Step 6: Select Computer Location"
        );

        computerPage.selectLocation(
                config.getLocation()
        );


        ExtentListener.getTest().info(
                "Step 7: Open Advanced Options"
        );

        computerPage.ClickAdvancedOption();


        ExtentListener.getTest().info(
                "Step 8: Configure No-Show Wait Time"
        );

        computerPage.enterNoShowWaitTime(
                config.getnoshowwaitTime()
        );


        ExtentListener.getTest().info(
                "Step 9: Configure Level 1 Warning"
        );

        computerPage.enterLevel1Warning(
                config.getLevelWarnining()
        );


        ExtentListener.getTest().info(
                "Step 10: Configure Level 2 Warning"
        );

        computerPage.enterLevel2Warning(
                config.getLevelWarning2()
        );


        ExtentListener.getTest().info(
                "Step 11: Configure Level 3 Warning"
        );

        computerPage.enterLevel3Warning(
                config.getLevelLevelWarning3()
        );



        ExtentListener.getTest().info(
                "Step 12: Configure Logging Level"
        );

        computerPage.clickLoggingLevel();


        ExtentListener.getTest().info(
                "Step 13: Enable Welcome Message"
        );

        computerPage.enableShowWelcomeMessage();


        ExtentListener.getTest().info(
                "Step 14: Enable AUP Message"
        );

        computerPage.enableShowAUPMessage();


        ExtentListener.getTest().info(
                "Step 15: Configure Inactivity Timeout"
        );

        computerPage.enterInactivityTimeout(
                config.getInactivityTimeout()
        );


        ExtentListener.getTest().info(
                "Step 16: Configure Lock Timeout"
        );

        computerPage.enterLockTimeout(
                config.getLockTime()
        );


        ExtentListener.getTest().info(
                "Step 17: Configure Automatic Reboot"
        );

        computerPage.ClickAutoReboot();


        ExtentListener.getTest().info(
                "Step 18: Configure Automatic Shutdown"
        );

        computerPage.ClickAutoShutdown();



        ExtentListener.getTest().info(
                "Step 19: Open Tags and Booking"
        );

        computerPage.clickTagsandBooking();


        ExtentListener.getTest().info(
                "Step 20: Open Add Tags"
        );

        computerPage.clickTagsAdd();


        ExtentListener.getTest().info(
                "Step 21: Select Computer Tag"
        );

        computerPage.selectTags(
                config.getComputerTags()
        );


        ExtentListener.getTest().info(
                "Step 22: Add Computer"
        );

        computerPage.clickAdd();


        // =========================
        // ACTUAL RESULT
        // =========================

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Computer details were entered, the location was selected, "
                + "advanced settings and power settings were configured, "
                + "and the required Computer Tag was selected. "
                + "The Add Computer action was performed."
        );
    }
}