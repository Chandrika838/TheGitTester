package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.AdminRoomPage;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class RoomTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to the Room module, "
            + "open Add New Room, enter the required room details and perform "
            + "the Submit operation.")
    public void verifyAddRoom() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Verify Admin menu is displayed");
        ExtentListener.getTest().info("• Navigate to Room");
        ExtentListener.getTest().info("• Verify Add New button is displayed");
        ExtentListener.getTest().info("• Open Add New Room");
        ExtentListener.getTest().info("• Verify Room Name field is displayed");
        ExtentListener.getTest().info("• Enter Room Name");
        ExtentListener.getTest().info("• Verify Location dropdown is displayed");
        ExtentListener.getTest().info("• Select Location");
        ExtentListener.getTest().info("• Open Advanced Options");
        ExtentListener.getTest().info("• Verify Preparation option is displayed");
        ExtentListener.getTest().info("• Select Preparation");
        ExtentListener.getTest().info("• Verify Submit button is displayed");
        ExtentListener.getTest().info("• Click Submit");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to navigate to the Room module, "
                + "open Add New Room, enter the required room details, select the "
                + "required options and perform the Submit operation."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                config.getEmail(),
                config.getPassword()
        );

        ExtentListener.getTest().info(
                "Step 2: Verify Admin menu is displayed"
        );

        AdminRoomPage adminroom =
                new AdminRoomPage(driver);

        Assert.assertTrue(
                adminroom.isAdminDispalyed(),
                "Admin is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 3: Navigate to Room"
        );

        adminroom.ClickAdmin();

        Assert.assertTrue(
                adminroom.isRoomDisplayed(),
                "Room is not displayed"
        );

        adminroom.ClickRoom();

        ExtentListener.getTest().info(
                "Step 4: Verify Add New button is displayed"
        );

        Assert.assertTrue(
                adminroom.isAddNewDisplayed(),
                "Add New button is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 5: Click Add New"
        );

        adminroom.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 6: Verify Room Name field is displayed"
        );

        Assert.assertTrue(
                adminroom.isRoomNameDisplayed(),
                "Room Name field is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 7: Enter Room Name"
        );

        adminroom.enterRoomName(
                config.getRoomname()
        );

        ExtentListener.getTest().info(
                "Step 8: Verify Location dropdown is displayed"
        );

        Assert.assertTrue(
                adminroom.isLocationDisplayed(),
                "Location dropdown is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 9: Select Location"
        );

        adminroom.selectLocation(
                config.getLocation()
        );

        ExtentListener.getTest().info(
                "Step 10: Open Advanced Options"
        );

        adminroom.ClickAdvanceOption1();

        ExtentListener.getTest().info(
                "Step 11: Verify Preparation option is displayed"
        );

        Assert.assertTrue(
                adminroom.isPrepartionDisplayed(),
                "Preparation dropdown is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 12: Select Preparation"
        );

        adminroom.selectPrepartion(
                config.getPrepration()
        );

        ExtentListener.getTest().info(
                "Step 13: Verify Submit button is displayed"
        );

        Assert.assertTrue(
                adminroom.isSubmitDisplayed(),
                "Submit button is not displayed"
        );

        ExtentListener.getTest().info(
                "Step 14: Click Submit"
        );

        adminroom.clickSubmit();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to the Room "
                + "module, opened Add New Room, entered the configured Room Name, "
                + "selected the Location and Preparation options, and performed "
                + "the Submit operation."
        );
    }
}