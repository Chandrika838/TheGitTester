package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.ComputersTags;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class ComputerTags extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can create a new Computer Tag "
            + "using a valid tag name and submit the tag successfully.")
    public void verifyAddComputers() {

        // =========================
        // SCENARIOS COVERED
        // =========================

        ExtentListener.getTest().info(
                "<b>Scenarios Covered:</b>"
        );

        ExtentListener.getTest().info(
                "• Login with valid administrator credentials"
        );

        ExtentListener.getTest().info(
                "• Navigate to Computer Tags"
        );

        ExtentListener.getTest().info(
                "• Open Add New Computer Tag"
        );

        ExtentListener.getTest().info(
                "• Enter a valid Computer Tag name"
        );

        ExtentListener.getTest().info(
                "• Add the Computer Tag"
        );

        ExtentListener.getTest().info(
                "• Verify Submit button is displayed"
        );


        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to navigate to Computer Tags, "
                + "enter a valid tag name, add the tag and proceed with the "
                + "Submit option successfully."
        );



        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();


        ExtentListener.getTest().info(
                "Step 2: Navigate to Computer Tags"
        );

        ComputersTags comp = new ComputersTags(driver);

        comp.clickAdmin();
        comp.clickTools();
        comp.clickComputerTools();
        comp.ClickTags();



        ExtentListener.getTest().info(
                "Step 3: Click Add New to create a Computer Tag"
        );

        comp.ClickAddNew();


   

        ExtentListener.getTest().info(
                "Step 4: Enter valid Computer Tag name"
        );

        String tagName = config.getComputerTags();

        comp.enterComputerTags(tagName);

        
        ExtentListener.getTest().info(
                "Step 5: Add the Computer Tag"
        );

        comp.clickAdd();



        ExtentListener.getTest().info(
                "Step 6: Verify Submit button is displayed"
        );

        Assert.assertTrue(
                comp.isDisplayedSubmit(),
                "Submit is not displayed"
        );


        // =========================
        // ACTUAL RESULT
        // =========================

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Computer Tags section was opened, a valid Computer Tag "
                + "name was entered and the Add action was performed. "
                + "The Submit button was displayed."
        );
    }
}