package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.DeskBookingRules;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class DeskBookingRulesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can configure Desk Booking Rules "
            + "including access, booking limits, booking duration and advance booking settings.")
    public void verifyAddDesk() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Desk Booking Rules");
        ExtentListener.getTest().info("• Open Desk Booking Rules configuration");
        ExtentListener.getTest().info("• Configure Access");
        ExtentListener.getTest().info("• Configure Maximum Bookings Per Month");
        ExtentListener.getTest().info("• Configure Maximum Booking Duration");
        ExtentListener.getTest().info("• Configure Bookings Per Day");
        ExtentListener.getTest().info("• Configure Maximum Allowed Per Day");
        ExtentListener.getTest().info("• Configure Maximum Advance Booking Period");
        ExtentListener.getTest().info("• Submit Desk Booking Rules");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to configure the required Desk Booking Rules, "
                + "verify each selected setting, and submit the configuration successfully."
        );

        // Step 1: Login
        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Step 2: Navigate to Desk Booking Rules
        ExtentListener.getTest().info(
                "Step 2: Navigate to Desk Booking Rules"
        );

        DeskBookingRules desk = new DeskBookingRules(driver);

        desk.clickAdmin();
        desk.clickTools();
        desk.ClickDesk();
        desk.ClickBookingRules();
        desk.ClickDeskPage();

        // Step 3: Configure Access
        ExtentListener.getTest().info(
                "Step 3: Configure Desk Access"
        );

        desk.clickAccess();

        Assert.assertTrue(
                desk.isAccessSelected(),
                "Access is not Selected"
        );

        // Step 4: Maximum Per Month
        ExtentListener.getTest().info(
                "Step 4: Configure Maximum Bookings Per Month"
        );

        desk.ClickMaximumPerMonth();

        Assert.assertTrue(
                desk.isMaximumPerMonthSelected(),
                "Maximum Per Month is not selected"
        );

        // Step 5: Maximum Booking Duration
        ExtentListener.getTest().info(
                "Step 5: Configure Maximum Booking Duration"
        );

        desk.ClickMaxiumBookingDuration();

        Assert.assertTrue(
                desk.isSelectedMaxiumBookingDuration(),
                "Maximum Booking Duration is not selected"
        );

        // Step 6: Booking Per Day
        ExtentListener.getTest().info(
                "Step 6: Configure Booking Per Day"
        );

        desk.ClickBookingPerDay();

        Assert.assertTrue(
                desk.isSelectedBookingPerDay(),
                "Booking Per Day is not Selected"
        );

        // Step 7: Maximum Allowed Per Day
        ExtentListener.getTest().info(
                "Step 7: Configure Maximum Allowed Bookings Per Day"
        );

        desk.ClickMaximumAllowedPerDay();

        Assert.assertTrue(
                desk.isSelectedMaxiumAllowedPPerDay(),
                "Maximum Allowed Per Day is not selected"
        );

        // Step 8: Maximum Advance Booking Period
        ExtentListener.getTest().info(
                "Step 8: Configure Maximum Advance Booking Period"
        );

        desk.ClickMaxiumperiodAdvance();

        Assert.assertTrue(
                desk.isSelectedMaxiumperiodAdvance(),
                "Maximum Advance Booking Period is not selected"
        );

        // Step 9: Submit
        ExtentListener.getTest().info(
                "Step 9: Verify Submit button and submit Desk Booking Rules"
        );

        Assert.assertTrue(
                desk.isSubmitDisplayed(),
                "Submit is not Displayed"
        );

        desk.ClickSubmit();

        // Actual Result
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Desk Booking Rules were configured for Access, Maximum Per Month, "
                + "Maximum Booking Duration, Booking Per Day, Maximum Allowed Per Day "
                + "and Maximum Advance Booking Period. All configured settings were "
                + "verified and the Submit operation was performed."
        );
    }
}