package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.Userspage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class UsersBookingRulesTags extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to Users Booking Rules, "
            + "configure the required booking rule settings and perform the Update operation.")
    public void VerifyAddUserTestCase() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Users");
        ExtentListener.getTest().info("• Navigate to Tags");
        ExtentListener.getTest().info("• Open Booking Rules");
        ExtentListener.getTest().info("• Configure Booking Rule option 1");
        ExtentListener.getTest().info("• Configure Booking Rule option 2");
        ExtentListener.getTest().info("• Configure Booking Rule option 3");
        ExtentListener.getTest().info("• Click Update");
        ExtentListener.getTest().info("• Verify Update option is displayed");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to navigate to Users Booking Rules, "
                + "configure the required booking rule settings and perform the Update operation."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Users Booking Rules"
        );

        Userspage users = new Userspage(driver);

        users.ClickAdmin();
        users.ClickTools();
        users.ClickUsers();
        users.ClickTags();

        ExtentListener.getTest().info(
                "Step 3: Open Booking Rules"
        );

        users.ClickTool();
        users.ClickBookingRules();

        ExtentListener.getTest().info(
                "Step 4: Configure Booking Rule option 1"
        );

        users.ClickBookingRules1();

        ExtentListener.getTest().info(
                "Step 5: Configure Booking Rule option 2"
        );

        users.ClickBookingRules2();

        ExtentListener.getTest().info(
                "Step 6: Configure Booking Rule option 3"
        );

        users.ClickBookingRules3();

        ExtentListener.getTest().info(
                "Step 7: Click Update"
        );

        users.ClickUpdate();

        ExtentListener.getTest().info(
                "Step 8: Verify Update option is displayed"
        );

        Assert.assertTrue(
                users.isDisplayedUpdate(),
                "Update is not Displayed"
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to Users Booking Rules, "
                + "configured the required booking rule options, performed the Update operation "
                + "and verified that the Update option was displayed."
        );
    }
}


