package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.ComputerBookingRules;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class ComputerBookingRulesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can configure Computer Booking Rules "
            + "including access, booking limits, extension settings and maximum extension time.")
    public void VerifyComputer() {

        // =========================
        // SCENARIOS COVERED
        // =========================

        ExtentListener.getTest().info(
                "<b>Scenarios Covered:</b>"
        );

        ExtentListener.getTest().info(
                "• Login with valid administrator credentials"
        );

        ExtentListener.getTest().info(
                "• Navigate to Computer Booking Rules"
        );

        ExtentListener.getTest().info(
                "• Open Computer Booking Rules Tags and Access settings"
        );

        ExtentListener.getTest().info(
                "• Configure Computer Booking Access"
        );

        ExtentListener.getTest().info(
                "• Configure Maximum Bookings Per Month"
        );

        ExtentListener.getTest().info(
                "• Configure Maximum Booking Duration"
        );

        ExtentListener.getTest().info(
                "• Configure Bookings Per Day"
        );

        ExtentListener.getTest().info(
                "• Configure Maximum Allowed Bookings Per Day"
        );

        ExtentListener.getTest().info(
                "• Configure Maximum Period to Book in Advance"
        );

        ExtentListener.getTest().info(
                "• Configure Booking Extension settings"
        );

        ExtentListener.getTest().info(
                "• Configure Auto Extend and Maximum Extension Time"
        );

        ExtentListener.getTest().info(
                "• Configure Number of Extensions"
        );

        ExtentListener.getTest().info(
                "• Verify and submit Computer Booking Rules"
        );


        // =========================
        // EXPECTED RESULT
        // =========================

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to configure the required "
                + "Computer Booking Rules, booking limits and extension settings, "
                + "and submit the configuration successfully."
        );


        // =========================
        // LOGIN
        // =========================

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();


        // =========================
        // COMPUTER BOOKING RULES
        // =========================

        ExtentListener.getTest().info(
                "Step 2: Navigate to Computer Booking Rules"
        );

        ComputerBookingRules comp =
                new ComputerBookingRules(driver);

        comp.ClickAdmin();

        comp.ClickTools();

        comp.ClickComputerTools();

        comp.ClickBookingRules();


        // =========================
        // TAGS
        // =========================

        ExtentListener.getTest().info(
                "Step 3: Open Computer Booking Rules Tags"
        );

        comp.ClickTags();


        // =========================
        // ACCESS
        // =========================

        ExtentListener.getTest().info(
                "Step 4: Open Access settings"
        );

        comp.ClickAccess();


        ExtentListener.getTest().info(
                "Step 5: Enable Computer Booking Access"
        );

        comp.enableToogle();


        // =========================
        // BOOKING LIMITS
        // =========================

        ExtentListener.getTest().info(
                "Step 6: Configure Maximum Bookings Per Month"
        );

        comp.enableInput(
                config.getMaximumPerMonth()
        );


        ExtentListener.getTest().info(
                "Step 7: Configure Maximum Booking Duration"
        );

        comp.enableInput1(
                config.getMaxiumBookingDuration()
        );


        ExtentListener.getTest().info(
                "Step 8: Configure Bookings Per Day"
        );

        comp.enableInput2(
                config.getBookingPerDay()
        );


        ExtentListener.getTest().info(
                "Step 9: Configure Maximum Allowed Bookings Per Day"
        );

        comp.enableInput3(
                config.getBookingAllowedPerDay()
        );


        ExtentListener.getTest().info(
                "Step 10: Configure Maximum Period to Book in Advance"
        );

        comp.enableInput4(
                config.getmaximumperiodtobookinadvance()
        );

        // EXTENSION SETTINGS
    

        ExtentListener.getTest().info(
                "Step 11: Open Booking Extension settings"
        );

        comp.ClickExtend();


        ExtentListener.getTest().info(
                "Step 12: Enable Booking Extension"
        );

        comp.enableToogle1();

        // AUTO EXTEND
  
        ExtentListener.getTest().info(
                "Step 13: Open Auto Extend settings"
        );

        comp.ClickAutoExtend();


        ExtentListener.getTest().info(
                "Step 14: Enable Auto Extend"
        );

        comp.enableToogle2();

        // MAXIMUM EXTENSION TIME
   

        ExtentListener.getTest().info(
                "Step 15: Configure Maximum Extension Time"
        );

        comp.ClickMaxmiumExtendTime();


        ExtentListener.getTest().info(
                "Step 16: Enable Maximum Extension Time option"
        );

        comp.ClickToogle3();

        // NUMBER OF EXTENSIONS
    
        ExtentListener.getTest().info(
                "Step 17: Configure Number of Extensions"
        );

        comp.clickNumberofExtension();


        ExtentListener.getTest().info(
                "Step 18: Enable Number of Extensions option"
        );

        comp.ClickToogle4();

        // SUBMIT
 
        ExtentListener.getTest().info(
                "Step 19: Submit Computer Booking Rules configuration"
        );

        comp.ClickSubmit();

        // ACTUAL RESULT
  
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Computer Booking Rules were configured for access, booking "
                + "limits and extension settings, and the Submit action was performed."
        );
    }
}

