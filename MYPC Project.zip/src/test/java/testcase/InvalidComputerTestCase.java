package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.ComputerPage;
import adminpage.LoginPage;
import automation.pages.utils.ExtentListener;

public class InvalidComputerTestCase extends BaseTest {

    @Test(description =
            "Verifies that the system displays the validation message when Computer Name "
            + "is blank and invalid values are entered in the Computer configuration.")
    public void VerifyBlankName() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Computers");
        ExtentListener.getTest().info("• Open Add New Computer");
        ExtentListener.getTest().info("• Leave Computer Name blank");
        ExtentListener.getTest().info("• Enter invalid Level 2 Warning value");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent the Computer from being added and "
                + "display the validation message <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Computers and open Add New Computer"
        );

        ComputerPage comp = new ComputerPage(driver);

        comp.ClickAdmin();
        comp.ClickComputers();
        comp.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave Computer Name blank"
        );

        comp.enterComputerName("");

        ExtentListener.getTest().info(
                "Step 4: Enter Computer ID and select Location"
        );

        comp.enterComputerID(config.getComputerID());
        comp.selectLocation(config.getLocation());

        ExtentListener.getTest().info(
                "Step 5: Configure Advanced Options with invalid Level 2 Warning"
        );

        comp.ClickAdvancedOption();
        comp.enterNoShowWaitTime(config.getnoshowwaitTime());
        comp.enterLevel1Warning("");
        comp.enterLevel2Warning("@");
        comp.enterLevel3Warning(config.getLevelLevelWarning3());

        comp.clickLoggingLevel();
        comp.enableShowWelcomeMessage();
        comp.enableShowAUPMessage();

        comp.enterInactivityTimeout(config.getInactivityTimeout());
        comp.enterLockTimeout(config.getLockTime());

        comp.ClickAutoReboot();
        comp.ClickAutoShutdown();

        ExtentListener.getTest().info(
                "Step 6: Click Add with invalid Computer details"
        );

        comp.clickAdd();

        ExtentListener.getTest().info(
                "Step 7: Verify validation message"
        );

        String actualMessage = comp.getInvalidEntry();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation Message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Computer Name was left blank and an invalid value was entered. "
                + "The system displayed <b>\"Invalid entry!\"</b> as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays a validation message when required "
            + "Computer Name and Computer ID fields are left blank.")
    public void VerifyInvalidCredentials() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Open Add New Computer");
        ExtentListener.getTest().info("• Leave Computer Name blank");
        ExtentListener.getTest().info("• Leave Computer ID blank");
        ExtentListener.getTest().info("• Leave required warning values blank");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent the Computer from being added when "
                + "required fields are blank and should display "
                + "<b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Computers and open Add New Computer"
        );

        ComputerPage comp = new ComputerPage(driver);

        comp.ClickAdmin();
        comp.ClickComputers();
        comp.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave Computer Name and Computer ID blank"
        );

        comp.enterComputerName("");
        comp.enterComputerID("");
        comp.selectLocation(config.getLocation());

        ExtentListener.getTest().info(
                "Step 4: Configure remaining Computer options with required values blank"
        );

        comp.ClickAdvancedOption();
        comp.enterNoShowWaitTime(config.getnoshowwaitTime());
        comp.enterLevel1Warning("");
        comp.enterLevel2Warning("");
        comp.enterLevel3Warning(config.getLevelLevelWarning3());

        comp.clickLoggingLevel();
        comp.enableShowWelcomeMessage();
        comp.enableShowAUPMessage();

        comp.enterInactivityTimeout(config.getInactivityTimeout());
        comp.enterLockTimeout(config.getLockTime());

        comp.ClickAutoReboot();
        comp.ClickAutoShutdown();

        ExtentListener.getTest().info(
                "Step 5: Click Add with required fields blank"
        );

        comp.clickAdd();

        ExtentListener.getTest().info(
                "Step 6: Verify validation message"
        );

        String actualMessage = comp.getInvalidEntry();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation Message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Required Computer fields were left blank. The system displayed "
                + "<b>\"Invalid entry!\"</b> as expected."
        );
    }


    @Test(description =
            "Verifies that the system displays a validation message when multiple "
            + "Computer configuration fields contain blank or invalid values.")
    public void VerifyInvalidCharacter() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Open Add New Computer");
        ExtentListener.getTest().info("• Leave Computer Name and ID blank");
        ExtentListener.getTest().info("• Leave warning fields blank");
        ExtentListener.getTest().info("• Leave timeout fields blank");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent the Computer from being added "
                + "and display the validation message <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Computers and open Add New Computer"
        );

        ComputerPage comp = new ComputerPage(driver);

        comp.ClickAdmin();
        comp.ClickComputers();
        comp.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave Computer Name and Computer ID blank"
        );

        comp.enterComputerName("");
        comp.enterComputerID("");
        comp.selectLocation(config.getLocation());

        ExtentListener.getTest().info(
                "Step 4: Configure Advanced Options with blank values"
        );

        comp.ClickAdvancedOption();
        comp.enterNoShowWaitTime(config.getnoshowwaitTime());
        comp.enterLevel1Warning("");
        comp.enterLevel2Warning("");
        comp.enterLevel3Warning("");

        comp.clickLoggingLevel();
        comp.enableShowWelcomeMessage();
        comp.enableShowAUPMessage();

        comp.enterInactivityTimeout("");
        comp.enterLockTimeout("");

        comp.ClickAutoReboot();
        comp.ClickAutoShutdown();

        ExtentListener.getTest().info(
                "Step 5: Click Add with invalid Computer configuration"
        );

        comp.clickAdd();

        ExtentListener.getTest().info(
                "Step 6: Verify validation message"
        );

        String actualMessage = comp.getInvalidEntry();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation Message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Multiple Computer configuration fields were left blank. "
                + "The system displayed <b>\"Invalid entry!\"</b> as expected."
        );
    }
}
	

