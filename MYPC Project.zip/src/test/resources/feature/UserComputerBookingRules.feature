@regression
Feature: User Computer Booking Rules

  Scenario: Verify user computer booking rules

    Given I am on the User Computer Booking Rules page

    When I enable access
    And I enable User computer access toggle

    And I enable maximum User computer bookings per month
    And I enter the maximum User computer bookings per month

    And I enable maximum User computer booking duration
    And I enter the maximum User computer booking duration

    And I enable User computer bookings per day
    And I enter the User computer bookings per day

    And I enable maximum allowed User computer booking time per day
    And I enter the maximum allowed User computer booking time per day

    And I enable maximum User computer booking advance period
    And I enter the maximum User computer booking advance period

    And I enable User computer booking extension
    And I enable User computer extension toggle

    And I enable automatic User computer extension
    And I enable automatic extension toggle

    And I enable maximum User computer extension time
    And I enable maximum extension time toggle

    And I enable number of User computer extensions
    And I enable number of extensions toggle

    And I submit the user computer booking rules