package testcase;

import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.RoomCopyProperites;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class RoomCopyPropertiesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can navigate to Room Copy Properties, "
            + "select a source room and target location, configure the required room "
            + "properties and perform the Copy operation.")
    public void VerifyCopyProperties() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Room Copy Properties");
        ExtentListener.getTest().info("• Select Source Room");
        ExtentListener.getTest().info("• Select Target Location");
        ExtentListener.getTest().info("• Enable Tags");
        ExtentListener.getTest().info("• Enable Room properties");
        ExtentListener.getTest().info("• Enable Test properties");
        ExtentListener.getTest().info("• Enable Settings");
        ExtentListener.getTest().info("• Enable Default properties");
        ExtentListener.getTest().info("• Enable Capacity");
        ExtentListener.getTest().info("• Enable Equipment");
        ExtentListener.getTest().info("• Enable Preparation Time");
        ExtentListener.getTest().info("• Enable Check-in Settings");
        ExtentListener.getTest().info("• Enable Check-in Tags");
        ExtentListener.getTest().info("• Click Copy");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The administrator should be able to select the source room and target "
                + "location, configure the required room properties and perform the "
                + "Copy operation successfully."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Room Copy Properties"
        );

        RoomCopyProperites copy =
                new RoomCopyProperites(driver);

        copy.ClickAdmin();
        copy.ClickTools();
        copy.ClickRooms();
        copy.ClickCopyProperties();

        ExtentListener.getTest().info(
                "Step 3: Select Source Room"
        );

        copy.SelectSource(
                config.getSourceRoom()
        );

        ExtentListener.getTest().info(
                "Step 4: Select Target Location"
        );

        copy.SelectLocation(
                config.getLocation()
        );

        ExtentListener.getTest().info(
                "Step 5: Enable Tags"
        );

        copy.enabletags();

        ExtentListener.getTest().info(
                "Step 6: Enable Room properties"
        );

        copy.enableRoom();

        ExtentListener.getTest().info(
                "Step 7: Enable Test properties"
        );

        copy.enableTest();

        ExtentListener.getTest().info(
                "Step 8: Enable Settings"
        );

        copy.enableSetting();

        ExtentListener.getTest().info(
                "Step 9: Enable Default properties"
        );

        copy.enableDefault();

        ExtentListener.getTest().info(
                "Step 10: Enable Capacity"
        );

        copy.enableCapacity();

        ExtentListener.getTest().info(
                "Step 11: Enable Equipment"
        );

        copy.enableEquipment();

        ExtentListener.getTest().info(
                "Step 12: Enable Preparation Time"
        );

        copy.enablePrepartionTime();

        ExtentListener.getTest().info(
                "Step 13: Enable Check-in Settings"
        );

        copy.enableCheckinSetting();

        ExtentListener.getTest().info(
                "Step 14: Enable Check-in Tags"
        );

        copy.enableCheckinTags1();

        ExtentListener.getTest().info(
                "Step 15: Click Copy"
        );

        copy.ClickCopy();

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The administrator logged in successfully, navigated to Room Copy "
                + "Properties, selected the source room and target location, configured "
                + "the required room properties and performed the Copy operation."
        );
    }
}