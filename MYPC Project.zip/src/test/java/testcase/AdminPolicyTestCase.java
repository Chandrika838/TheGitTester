package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.AdminPolicy;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;

public class AdminPolicyTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(
        description = "Verifies that an administrator can create a new Admin Policy by selecting a valid User Tag and Admin Policy."
    )
    public void verifyAddTestCase() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());

        loginPage.enterPassword(config.getPassword());

        loginPage.enableHighContrast();

        loginPage.clickLogin();


        // Create Admin Policy page object
        AdminPolicy admin = new AdminPolicy(driver);


        // Navigate to Admin
        admin.ClickAdmin();


        // Navigate to Tools
        admin.clickTools();


        // Navigate to User Tools
        admin.ClickUsersTools();


        // Open Admin Policy
        admin.ClickAdminpolicy();


        // Click Add New
        admin.ClickAddnew();


        // Select User Tag
        admin.selectUserTag(
            config.getUserTag()
        );


        // Select Admin Policy
        admin.SelectAdminPolicy(
            config.getAdminPolicy()
        );


        // Verify Submit button
        Assert.assertTrue(
            admin.isSubmitDisplayed(),
            "Submit button is not displayed"
        );


        // Submit Admin Policy
        admin.ClickSubmit();
    }
}