Feature: Computer Report functionality

  Scenario: Verify Computer Report
    Given I open the application
    When I enter valid email
    And I enter valid password
    And I click the login button
    When I click Reports for Computer Report
    And I click Computer Report
    And I select the computer report location
    And I select the computer report month
    And I select the computer report booking type
    And I click the computer report pie chart
    Then the computer report pie chart should be displayed