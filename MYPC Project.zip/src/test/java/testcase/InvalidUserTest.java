package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.UserPage;
import automation.pages.utils.ExtentListener;

public class InvalidUserTest extends BaseTest {

    @Test(description =
            "Verifies that the system displays a validation message when "
            + "the First Name field is left blank while inviting a user.")
    public void VerifyBlankFirst() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Invite Users page");
        ExtentListener.getTest().info("• Leave First Name blank");
        ExtentListener.getTest().info("• Enter valid Last Name");
        ExtentListener.getTest().info("• Click Submit");
        ExtentListener.getTest().info("• Verify First Name validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should not allow user creation when the First Name field is blank."
        );

        ExtentListener.getTest().info("Step 1: Login to MYPC");

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info("Step 2: Navigate to Invite Users");

        UserPage user = new UserPage(driver);

        user.clickAdmnMenu();
        user.clickUserMenu();
        user.clickInviteUsers();

        ExtentListener.getTest().info("Step 3: Leave First Name blank");

        user.enterFirstName("");

        ExtentListener.getTest().info("Step 4: Enter valid Last Name");

        user.enterLastName(config.getLastName());

        ExtentListener.getTest().info("Step 5: Click Submit");

        user.clickSubmit();

        ExtentListener.getTest().info("Step 6: Verify validation message");

        Assert.assertTrue(
                user.FirstNameisDisplayedInvalid(),
                "Invalid message is not displayed"
        );

        ExtentListener.getTest().pass(
                "Application displayed validation message for blank First Name."
        );
    }

    @Test(description =
            "Verifies that the system displays a validation message when "
            + "the Last Name field is left blank while inviting a user.")
    public void VerifyBlankLastName() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Invite Users page");
        ExtentListener.getTest().info("• Enter valid First Name");
        ExtentListener.getTest().info("• Leave Last Name blank");
        ExtentListener.getTest().info("• Click Submit");
        ExtentListener.getTest().info("• Verify Last Name validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should not allow user creation when the Last Name field is blank."
        );

        ExtentListener.getTest().info("Step 1: Login to MYPC");

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info("Step 2: Navigate to Invite Users");

        UserPage user = new UserPage(driver);

        user.clickAdmnMenu();
        user.clickUserMenu();
        user.clickInviteUsers();

        ExtentListener.getTest().info("Step 3: Enter valid First Name");

        user.enterFirstName(config.getFirstName());

        ExtentListener.getTest().info("Step 4: Leave Last Name blank");

        user.enterLastName("");

        ExtentListener.getTest().info("Step 5: Click Submit");

        user.clickSubmit();

        ExtentListener.getTest().info("Step 6: Verify validation message");

        Assert.assertTrue(
                user.LastNameisDisplayedInvalid(),
                "Last Name validation message is not displayed"
        );

        ExtentListener.getTest().pass(
                "Application displayed validation message for blank Last Name."
        );
    }

    @Test(description =
            "Verifies that the system displays a validation message when "
            + "invalid characters are entered in the First Name field.")
    public void VerifyInvalidCharacter() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Invite Users page");
        ExtentListener.getTest().info("• Enter invalid First Name characters");
        ExtentListener.getTest().info("• Enter valid Last Name");
        ExtentListener.getTest().info("• Click Submit");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should reject special characters entered in the First Name field."
        );

        ExtentListener.getTest().info("Step 1: Login to MYPC");

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info("Step 2: Navigate to Invite Users");

        UserPage user = new UserPage(driver);

        user.clickAdmnMenu();
        user.clickUserMenu();
        user.clickInviteUsers();

        ExtentListener.getTest().info("Step 3: Enter invalid characters");

        user.enterFirstName("@#@@");

        ExtentListener.getTest().info("Step 4: Enter valid Last Name");

        user.enterLastName(config.getLastName());

        ExtentListener.getTest().info("Step 5: Click Submit");

        user.clickSubmit();

        ExtentListener.getTest().info("Step 6: Verify validation message");

        Assert.assertTrue(
                user.FirstNameisDisplayedInvalid(),
                "Invalid character message is not displayed"
        );

        ExtentListener.getTest().pass(
                "Application correctly rejected invalid First Name characters."
        );
    }
}
