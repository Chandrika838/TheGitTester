package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.ComputerLocationProperties;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class ComputerCopyPropertiesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can copy computer location properties "
            + "from a source computer to the selected location with the required "
            + "configuration options.")
    public void verifyAddCopyProperites() {

        

        ExtentListener.getTest().info(
                "<b>Scenarios Covered:</b>"
        );

        ExtentListener.getTest().info(
                "• Login with valid administrator credentials"
        );

        ExtentListener.getTest().info(
                "• Navigate to Computer Copy Properties"
        );

        ExtentListener.getTest().info(
                "• Verify Copy Properties page is displayed"
        );

        ExtentListener.getTest().info(
                "• Select source computer"
        );

        ExtentListener.getTest().info(
                "• Select target location"
        );

        ExtentListener.getTest().info(
                "• Configure Tags and Location properties"
        );

        ExtentListener.getTest().info(
                "• Configure default time and booking settings"
        );

        ExtentListener.getTest().info(
                "• Configure preparation and check-in settings"
        );

        ExtentListener.getTest().info(
                "• Configure level times and logging settings"
        );

        ExtentListener.getTest().info(
                "• Configure welcome and application messages"
        );

        ExtentListener.getTest().info(
                "• Configure automatic reboot, shutdown and lock timeout settings"
        );

        ExtentListener.getTest().info(
                "• Copy the selected computer properties"
        );


        // EXPECTED RESULT


        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to select a source computer "
                + "and target location, configure the required computer properties, "
                + "and perform the Copy Properties operation successfully."
        );



        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();


        // =========================
        // NAVIGATION
        // =========================

        ExtentListener.getTest().info(
                "Step 2: Navigate to Computer Copy Properties"
        );

        ComputerLocationProperties copy =
                new ComputerLocationProperties(driver);

        copy.ClickAdmin();

        copy.ClickTools();

        copy.ClickComputerTools();

        copy.clickCopyProperties();


        ExtentListener.getTest().info(
                "Step 3: Verify Copy Properties page is displayed"
        );

        Assert.assertTrue(
                copy.CopyPropertiesisDisplayed(),
                "Copy properties is not displayed"
        );


 

        ExtentListener.getTest().info(
                "Step 4: Select source computer"
        );

        copy.SelectSource(
                config.getComputerName()
        );


        ExtentListener.getTest().info(
                "Step 5: Select target location"
        );

        copy.SelectLocation(
                config.getLocations()
        );



        ExtentListener.getTest().info(
                "Step 6: Enable and verify Tags"
        );

        copy.enableTags();

        Assert.assertTrue(
                copy.TagsisSelected(),
                "Tags is not selected"
        );


        ExtentListener.getTest().info(
                "Step 7: Configure additional Tags property"
        );

        copy.enableTags1();



        ExtentListener.getTest().info(
                "Step 8: Configure Location property"
        );

        copy.enableLocation();



        ExtentListener.getTest().info(
                "Step 9: Configure Default Time"
        );

        copy.enabledfaulttime();



        ExtentListener.getTest().info(
                "Step 10: Configure Allowed Booking Method"
        );

        copy.enableallowedBookingMethod();


        ExtentListener.getTest().info(
                "Step 11: Configure Preparation Time"
        );

        copy.enableprepartime();


        ExtentListener.getTest().info(
                "Step 12: Configure Check-in Settings"
        );

        copy.enablecheckinsetting();


        ExtentListener.getTest().info(
                "Step 13: Configure Level 1 Time"
        );

        copy.enablelevel1time();


        ExtentListener.getTest().info(
                "Step 14: Configure Level 2 Time"
        );

        copy.enablelevel2time();


        ExtentListener.getTest().info(
                "Step 15: Configure Level 3 Time"
        );

        copy.enablelevel3time();


        ExtentListener.getTest().info(
                "Step 16: Configure Logging Level"
        );

        copy.enablelogginglevel();


        ExtentListener.getTest().info(
                "Step 17: Configure Welcome Message"
        );

        copy.enableWlecomeMessage();


        ExtentListener.getTest().info(
                "Step 18: Configure Application Message"
        );

        copy.enableaupMessage();


        ExtentListener.getTest().info(
                "Step 19: Configure Automatic Reboot setting"
        );

        copy.enableAllowautoRebot();


        ExtentListener.getTest().info(
                "Step 20: Configure Automatic Shutdown setting"
        );

        copy.enableallowAutoShutdown();


       

        ExtentListener.getTest().info(
                "Step 21: Configure Lock Timeout"
        );

        copy.enablelocktimeout();


        ExtentListener.getTest().info(
                "Step 22: Perform Copy Properties operation"
        );

        copy.ClickCopy();


        ExtentListener.getTest().info(
                "Step 23: Verify Copy operation result"
        );

        Assert.assertTrue(
                copy.isDisplayed(),
                "Copy is not displayed"
        );


        // ACTUAL RESULT
      

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Copy Properties page was displayed, the source computer "
                + "and target location were selected, the configured computer "
                + "properties were enabled, and the Copy operation was performed."
        );
    }
}
