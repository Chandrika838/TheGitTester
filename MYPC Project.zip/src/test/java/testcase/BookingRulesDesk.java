
package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.DeskBookingRules;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class BookingRulesDesk extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can configure Desk Booking Rules "
            + "including access, booking limits, duration and advance booking settings.")
    public void verifyAddDeskBookingRules() {

        // =========================
        // SCENARIOS COVERED
        // =========================

        ExtentListener.getTest().info(
                "<b>Scenarios Covered:</b>"
        );

        ExtentListener.getTest().info(
                "• Login with valid administrator credentials"
        );

        ExtentListener.getTest().info(
                "• Navigate to Desk Booking Rules"
        );

        ExtentListener.getTest().info(
                "• Configure Access settings"
        );

        ExtentListener.getTest().info(
                "• Configure Maximum Bookings Per Month"
        );

        ExtentListener.getTest().info(
                "• Configure Maximum Booking Duration"
        );

        ExtentListener.getTest().info(
                "• Configure Bookings Per Day"
        );

        ExtentListener.getTest().info(
                "• Configure Maximum Allowed Per Day"
        );

        ExtentListener.getTest().info(
                "• Configure Maximum Period Advance"
        );

        ExtentListener.getTest().info(
                "• Verify Submit button and submit the Desk Booking Rules"
        );

        // EXPECTED RESULT
  

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to navigate to Desk Booking Rules, "
                + "configure the required booking restrictions and limits, "
                + "and submit the configuration successfully."
        );


     
        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // DESK BOOKING RULES PAGE
  
        ExtentListener.getTest().info(
                "Step 2: Navigate to Desk Booking Rules"
        );

        DeskBookingRules desk = new DeskBookingRules(driver);

        desk.clickAdmin();
        desk.clickTools();
        desk.ClickDesk();
        desk.ClickBookingRules();
        desk.ClickDeskPage();

        // ACCESS

        ExtentListener.getTest().info(
                "Step 3: Configure Access setting"
        );

        desk.clickAccess();

        Assert.assertTrue(
                desk.isAccessSelected(),
                "Access is not selected"
        );

        // MAXIMUM PER MONTH
   
        ExtentListener.getTest().info(
                "Step 4: Configure Maximum Per Month"
        );

        desk.ClickMaximumPerMonth();

        Assert.assertTrue(
                desk.isMaximumPerMonthSelected(),
                "Maximum Per Month is not selected"
        );

        // MAXIMUM BOOKING DURATION
        

        ExtentListener.getTest().info(
                "Step 5: Configure Maximum Booking Duration"
        );

        desk.ClickMaxiumBookingDuration();

        Assert.assertTrue(
                desk.isSelectedMaxiumBookingDuration(),
                "Maximum Booking Duration is not selected"
        );

        // BOOKING PER DAY
     
        ExtentListener.getTest().info(
                "Step 6: Configure Booking Per Day"
        );

        desk.ClickBookingPerDay();

        Assert.assertTrue(
                desk.isSelectedBookingPerDay(),
                "Booking Per Day is not selected"
        );

        // MAXIMUM ALLOWED PER DAY
    
        ExtentListener.getTest().info(
                "Step 7: Configure Maximum Allowed Per Day"
        );

        desk.ClickMaximumAllowedPerDay();

        Assert.assertTrue(
                desk.isSelectedMaxiumAllowedPPerDay(),
                "Maximum Allowed Per Day is not selected"
        );

        // MAXIMUM PERIOD ADVANCE
     
        ExtentListener.getTest().info(
                "Step 8: Configure Maximum Period Advance"
        );

        desk.ClickMaxiumperiodAdvance();

        Assert.assertTrue(
                desk.isSelectedMaxiumperiodAdvance(),
                "Maximum Period Advance is not selected"
        );

        // SUBMIT
  
        ExtentListener.getTest().info(
                "Step 9: Verify Submit button is displayed"
        );

        Assert.assertTrue(
                desk.isSubmitDisplayed(),
                "Submit button is not displayed"
        );


        ExtentListener.getTest().info(
                "Step 10: Submit Desk Booking Rules configuration"
        );

        desk.ClickSubmit();

        // ACTUAL RESULT
    
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Desk Booking Rules settings were configured for Access, "
                + "booking limits, booking duration and advance booking period. "
                + "The Submit button was displayed and the configuration was submitted."
        );
    }
}