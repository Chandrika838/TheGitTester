package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.AdminRoomPage;
import adminpage.LoginPage;
import automation.pages.utils.ExtentListener;

public class InvalidRoomScenario extends BaseTest {

    @Test(description =
            "Verifies that the system displays the validation message when "
            + "an administrator attempts to create a Room with a blank Room Name.")
    public void VerifyBlankRoom() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Room");
        ExtentListener.getTest().info("• Open Add New Room");
        ExtentListener.getTest().info("• Leave Room Name blank");
        ExtentListener.getTest().info("• Enter valid Location, Duration and Capacity");
        ExtentListener.getTest().info("• Configure Room equipment options");
        ExtentListener.getTest().info("• Click Submit");
        ExtentListener.getTest().info("• Verify validation message");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent Room creation when the Room Name "
                + "is blank and display <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to Room and open Add New"
        );

        AdminRoomPage room = new AdminRoomPage(driver);

        room.ClickAdmin();
        room.ClickRoom();
        room.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 3: Leave the mandatory Room Name field blank"
        );

        room.enterRoomName("");

        ExtentListener.getTest().info(
                "Step 4: Enter valid Location, Default Duration and Capacity"
        );

        room.selectLocation(config.getLocation());
        room.enterDefaultDUration(config.getDuration());
        room.enterCapacityvalue(config.getCapacity());

        ExtentListener.getTest().info(
                "Step 5: Open Advanced Options and configure Room equipment"
        );

        room.ClickAdvanceOption1();
        room.enablecheckRoomCamera();
        room.enablecheckRoomMonitor();
        room.enablecheckRoomProjector();

        ExtentListener.getTest().info(
                "Step 6: Click Submit"
        );

        room.clickSubmit();

        ExtentListener.getTest().info(
                "Step 7: Verify validation message"
        );

        String actualMessage = room.getInvalidMessage();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "Room creation was prevented because the Room Name was left blank. "
                + "The system displayed <b>\"Invalid entry!\"</b> as expected."
        );
    }
}
