Feature: Room Tags Functionality

  Scenario: Verify Room Tags

    Given I open the application

    When I enter valid email

    And I enter valid password

    And I click the login button

    And I open the Admin menu

    When I open Tools

    And I click Room Tools

    And I click Tags

    And I click RoomTags Add New

    And I enter the room tag name

    And I click Add

    Then the room tag should be created



