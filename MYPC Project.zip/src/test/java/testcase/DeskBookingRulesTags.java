package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.DeskBookingRulestags;
import adminpage.LoginPage;
import automation.pages.utils.ConfigReader;
import automation.pages.utils.ExtentListener;

public class DeskBookingRulesTags extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test(description =
            "Verifies that an administrator can create and update a Desk Booking Rule Tag "
            + "using a valid Automation Tag.")
    public void verifyDeskBookingRulesTags() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Navigate to Desk Booking Rules Tags");
        ExtentListener.getTest().info("• Open Add New Booking Rule Tag");
        ExtentListener.getTest().info("• Select Automation Tag");
        ExtentListener.getTest().info("• Continue with the selected tag");
        ExtentListener.getTest().info("• Update the Booking Rule Tag");
        ExtentListener.getTest().info("• Perform the final Update operation");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "Administrator should be able to navigate to Desk Booking Rule Tags, "
                + "select a valid Automation Tag, continue with the configuration, "
                + "and perform the required update operations successfully."
        );

        // Step 1: Login
        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Step 2: Navigation
        ExtentListener.getTest().info(
                "Step 2: Navigate to Desk Booking Rules Tags"
        );

        DeskBookingRulestags desk =
                new DeskBookingRulestags(driver);

        desk.ClickAdmin();
        desk.ClickTools();
        desk.ClickDesk();
        desk.ClickTags();
        desk.ClickTool();
        desk.ClickBookingRules();

        // Step 3: Add New
        ExtentListener.getTest().info(
                "Step 3: Click Add New to create a Desk Booking Rule Tag"
        );

        desk.ClickAddNew();

        Assert.assertTrue(
                desk.isDisplayedAddNew(),
                "Add New button is not displayed"
        );

        // Step 4: Select Automation Tag
        ExtentListener.getTest().info(
                "Step 4: Select the Automation Tag"
        );

        desk.SelectID("Automation Tags");

        // Step 5: Continue
        ExtentListener.getTest().info(
                "Step 5: Click Continue"
        );

        desk.ClickContinue();

        Assert.assertTrue(
                desk.isDisplayedContinue(),
                "Continue button is not displayed"
        );

        // Step 6: Update
        ExtentListener.getTest().info(
                "Step 6: Click Update"
        );

        desk.ClickUpdate();

        Assert.assertTrue(
                desk.isDisplayedUpdate(),
                "Update button is not displayed"
        );

        // Step 7: Final Update
        ExtentListener.getTest().info(
                "Step 7: Perform the final Update operation"
        );

        desk.ClickUpdate1();

        Assert.assertTrue(
                desk.isDisplayedUpdate1(),
                "Final Update button is not displayed"
        );

        // Actual Result
        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "The Desk Booking Rule Tag configuration was opened, "
                + "the Automation Tag was selected, and the Continue and "
                + "Update operations were performed. The required buttons "
                + "were displayed as expected."
        );
    }
}

