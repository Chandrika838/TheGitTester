Feature:User Report Functionality

Scenario: Verify User Report 

Given I open the application 
When I enter the valid email 
When I enter the valid Password 
When I enter the login button 

And I open the admin menu 
And I open the Tools 
