package testcase.reports;

import org.testng.Assert;
import org.testng.annotations.Test;

import testcase.BaseTest;
import adminpage.LoginPage;

import reports.ComputerPage;
import automation.pages.utils.ConfigReader;

public class ComputerTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test

	public void VerifyAddUserTest() {
		
	// creating a constructor for the login Page 
		
   LoginPage loginPage = new LoginPage(driver);
   
   loginPage.enterEmail(config.getEmail());
   loginPage.enterPassword(config.getPassword());
   loginPage.clickLogin();
   
   
   // creating an constructor for UserTest Case 
   
   ComputerPage comp = new ComputerPage(driver);
   
   comp.ClickReport();
   
   comp.ClickComputerReport();
   
   comp.SelectLocation(config.getLocation());
   
   
   comp.SelectMonth(config.getperiod());
   
   comp.SelectBookingType(config.getBookingType());
   
   comp.ClickPieChart();
   
   Assert.assertTrue(comp.isDisplayedPiechart(),"Pie chart is not displayed ");
   
   
   
	}
}
	

