package testcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import adminpage.LoginPage;
import adminpage.UsersTags;
import automation.pages.utils.ExtentListener;

public class InvalidUsersTagsTestCase extends BaseTest {

    @Test(description =
            "Verifies that the system displays the validation message when "
            + "an administrator attempts to create a User Tag with a blank name.")
    public void VerifyInvalidTags() {

        ExtentListener.getTest().info("<b>Scenarios Covered:</b>");
        ExtentListener.getTest().info("• Login with valid administrator credentials");
        ExtentListener.getTest().info("• Enable High Contrast");
        ExtentListener.getTest().info("• Navigate to User Tags");
        ExtentListener.getTest().info("• Open Add New User Tag");
        ExtentListener.getTest().info("• Leave User Tag name blank");
        ExtentListener.getTest().info("• Click Add");
        ExtentListener.getTest().info("• Verify Submit button is displayed");
        ExtentListener.getTest().info("• Verify Invalid Message is displayed");
        ExtentListener.getTest().info("• Verify validation message is 'Invalid entry!'");

        ExtentListener.getTest().info(
                "<b>Expected Result:</b><br>" +
                "The system should prevent User Tag creation when the User Tag name "
                + "is blank and display the validation message <b>\"Invalid entry!\"</b>."
        );

        ExtentListener.getTest().info(
                "Step 1: Login to MYPC using valid administrator credentials"
        );

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.enableHighContrast();
        loginPage.clickLogin();

        ExtentListener.getTest().info(
                "Step 2: Navigate to User Tags"
        );

        UsersTags users = new UsersTags(driver);

        users.ClickAdmin();
        users.ClickTools();
        users.ClickUsersTool();
        users.ClickTags();

        ExtentListener.getTest().info(
                "Step 3: Click Add New User Tag"
        );

        users.ClickAddNew();

        ExtentListener.getTest().info(
                "Step 4: Leave the User Tag name blank"
        );

        users.enterUsersTag("");

        ExtentListener.getTest().info(
                "Step 5: Click Add"
        );

        users.clickAdd();

        ExtentListener.getTest().info(
                "Step 6: Verify Submit button is displayed"
        );

        Assert.assertTrue(
                users.isDisplayedAddSubmit(),
                "Submit is not Displayed"
        );

        ExtentListener.getTest().info(
                "Step 7: Verify Invalid Message is displayed"
        );

        Assert.assertTrue(
                users.isInvalidMessageDisplayed(),
                "Invalid Message is not Displayed"
        );

        ExtentListener.getTest().info(
                "Step 8: Verify validation message is 'Invalid entry!'"
        );

        String actualMessage = users.getInvalidMessage();

        ExtentListener.getTest().info(
                "<b>Actual Validation Message:</b> " + actualMessage
        );

        Assert.assertEquals(
                actualMessage,
                "Invalid entry!",
                "Validation message is incorrect."
        );

        ExtentListener.getTest().info(
                "<b>Actual Result:</b><br>" +
                "User Tag creation was prevented because the User Tag name "
                + "was left blank. The system displayed the Invalid Message, "
                + "and the validation message was verified as "
                + "<b>\"Invalid entry!\"</b> as expected."
        );
    }
}


	

	

